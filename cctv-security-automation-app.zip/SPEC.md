# SecureWatch - CCTV Security Automation System

## Concept & Vision

SecureWatch is a professional-grade CCTV security automation platform that transforms your CP PLUS camera system into an intelligent, proactive security solution. When someone approaches your property, you'll know instantly with video clips and smart notifications. The interface feels like a mission control center—confident, trustworthy, and always vigilant—while remaining intuitive enough for home users.

The system prioritizes **reliable detection over constant streaming**, using CP PLUS's built-in motion events when available, supplemented by AI analysis for person detection and face recognition powered by Google's Gemini AI.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SECUREWATCH ARCHITECTURE                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐         ┌──────────────────────────────────────────┐     │
│  │   Mobile     │         │           SecureWatch Backend             │     │
│  │   App        │◄───────►│  ┌─────────────────────────────────────┐  │     │
│  │  (Next.js)   │   HTTPS │  │      API Server (Next.js)            │  │     │
│  └──────────────┘         │  │  - REST API                         │  │     │
│                           │  │  - WebSocket (live view)            │  │     │
│                           │  │  - Authentication (JWT)             │  │     │
│                           │  └─────────────────────────────────────┘  │     │
│                           │                    │                        │     │
│                           │  ┌─────────────────┼────────────────────┐  │     │
│                           │  │                 │                    │  │     │
│                           │  ▼                 ▼                    ▼  │     │
│                           │ ┌──────────┐ ┌────────────┐ ┌──────────┐  │     │
│                           │ │ Motion   │ │ Face       │ │ Video    │  │     │
│                           │ │ Detection│ │ Recognition│ │ Recording│  │     │
│                           │ │ Service  │ │ (Gemini)   │ │ Service  │  │     │
│                           │ └──────────┘ └────────────┘ └──────────┘  │     │
│                           └──────────────────────────────────────────┘     │
│                                       │                                    │
│                           ┌───────────┴───────────┐                        │
│                           ▼                       ▼                        │
│                  ┌─────────────────┐     ┌─────────────────┐                │
│                  │   PostgreSQL    │     │  File Storage   │                │
│                  │   (Metadata)    │     │  (Video/Images) │                │
│                  └─────────────────┘     └─────────────────┘                │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                    CP PLUS CCTV SYSTEM                                 │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐    │  │
│  │  │   DVR/NVR   │──│  Camera 1   │──│  Camera 2   │──│  Camera N   │    │  │
│  │  │  (CP PLUS)  │  │  (RTSP/ONVIF)│  │  (RTSP/ONVIF)│  │  (RTSP/ONVIF)│   │  │
│  │  └──────┬──────┘  └─────────────┘  └─────────────┘  └─────────────┘    │  │
│  │         │                                                                  │  │
│  │         │ RTSP/ONVIF/CGI/HTTP Event Stream                               │  │
│  └─────────┼────────────────────────────────────────────────────────────────┘  │
│            │                                                                   │
└────────────┼───────────────────────────────────────────────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         NOTIFICATION DELIVERY                                │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐   │
│  │   Push      │    │    Email    │    │    SMS      │    │   Webhook   │   │
│  │  (Firebase) │    │  (Optional) │    │ (Optional)  │    │ (Optional)  │   │
│  └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## CP PLUS Integration Method

### Supported Protocols (in order of preference)

1. **HTTP Event Stream (Recommended)**
   - CP PLUS DVR/NVR provides HTTP push events for motion detection
   - Webhook endpoint on our server receives events
   - Lowest latency, uses device's own detection algorithm

2. **CGI/API Commands**
   - HTTP-based API for camera control and event subscription
   - Login: `http://[camera]/cgi-bin/login.cgi?username=X&password=Y`
   - Event subscribe: `http://[camera]/cgi-bin/eventManager.cgi?action=attach&codes=[EventCode]`
   - Used for: PTZ control, recording triggers, settings changes

3. **ONVIF Protocol**
   - Standardized IP camera interface
   - Used for: Device discovery, stream URIs, event subscription
   - WS-Discovery for automatic device finding

4. **RTSP Stream**
   - Real-Time Streaming Protocol for video
   - Format: `rtsp://[user]:[pass]@[ip]:[port]/[channel]/[stream]`
   - Used for: Live viewing, video recording

### CP PLUS Specific Integration Points

```typescript
// Common CP PLUS DVR/NVR URLs
const CPPLUS_ENDPOINTS = {
  // Device Info
  deviceInfo: '/cgi-bin/systemMgr.cgi?method=get&moduleName=system',
  
  // Login
  login: '/cgi-bin/login.cgi',
  
  // Channel List
  channels: '/cgi-bin/video.cgi?action=list',
  
  // Event Configuration
  motionConfig: '/cgi-bin/recordMgr.cgi?method=get&action=motion',
  motionEnable: '/cgi-bin/recordMgr.cgi?method=set&action=motion&enable=1',
  
  // Stream URLs
  rtspMain: 'rtsp://{ip}:{port}/Streaming/Channels/{channel}01',
  rtspSub: 'rtsp://{ip}:{port}/Streaming/Channels/{channel}02',
  
  // Event Stream
  eventStream: '/cgi-bin/eventManager.cgi?action=attach&codes=[MotionDetection]&timeout=60',
  
  // PTZ Control
  ptzControl: '/cgi-bin/ptz.cgi?action=start&channel={ch}&code={cmd}&arg1={speed}',
};
```

---

## Database Structure

### Entity Relationship Diagram

```
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│    User     │       │  Camera     │       │   Event     │
├─────────────┤       ├─────────────┤       ├─────────────┤
│ id          │◄──────│ userId      │       │ id          │
│ email       │       │ id          │◄──────│ cameraId    │
│ password    │       │ name        │       │ type        │
│ name        │       │ ip          │       │ thumbnailUrl│
│ createdAt   │       │ port        │       │ videoUrl    │
│ updatedAt   │       │ username    │       │ confidence  │
│ role        │       │ password    │       │ metadata    │
│ settings    │       │ protocol    │       │ createdAt   │
└─────────────┘       │ channel     │       │ isRead      │
       │              │ streamUrl   │       │ personId    │──────┐
       │              │ status      │       └─────────────┘      │
       │              │ detectionZones│                         │
       │              │ sensitivity   │                    ┌─────┴─────┐
       │              │ motionEnabled │                    │ KnownPerson│
       │              │ personEnabled │                    ├───────────┤
       │              │ faceEnabled   │                    │ id        │
       │              │ createdAt    │                    │ userId    │
       │              │ updatedAt    │                    │ name      │
       │              └──────────────┘                    │ imageUrl  │
       │                     │                            │ embeddings│
       │                     │                            │ confidence│
       └─────────────────────┼────────────────────────────│ createdAt │
                             │                            │ updatedAt │
                             ▼                            └───────────┘
                      ┌──────────────┐
                      │ Notification │
                      │   Setting    │
                      ├──────────────┤
                      │ id           │
                      │ userId       │
                      │ pushEnabled  │
                      │ personOnly   │
                      │ motionEnabled│
                      │ unknownOnly  │
                      │ quietStart   │
                      │ quietEnd     │
                      │ cameraIds    │
                      └──────────────┘
```

---

## Design Language

### Aesthetic Direction
**"Security Operations Center"** - Inspired by professional surveillance interfaces with a modern, approachable twist. Dark mode primary with accent colors that convey alertness without alarm. Clean data visualization, status indicators that are immediately scannable.

### Color Palette
```css
--bg-primary: #0f172a;        /* Slate 900 - Main background */
--bg-secondary: #1e293b;      /* Slate 800 - Cards, sidebar */
--bg-tertiary: #334155;        /* Slate 700 - Elevated elements */
--text-primary: #f8fafc;       /* Slate 50 */
--text-secondary: #94a3b8;     /* Slate 400 */
--text-muted: #64748b;         /* Slate 500 */
--accent-primary: #3b82f6;     /* Blue 500 - Primary actions */
--accent-success: #22c55e;      /* Green 500 - Online, safe */
--accent-warning: #f59e0b;      /* Amber 500 - Warnings */
--accent-danger: #ef4444;       /* Red 500 - Alerts, critical */
--accent-info: #06b6d4;         /* Cyan 500 - Information */
--border-color: #475569;       /* Slate 600 */
```

### Typography
- **Primary Font**: Inter (Google Fonts) - Clean, professional, excellent readability
- **Monospace**: JetBrains Mono - For technical data, timestamps, IPs
- **Fallbacks**: system-ui, -apple-system, sans-serif

### Spatial System
- Base unit: 4px
- Spacing scale: 4, 8, 12, 16, 24, 32, 48, 64, 96
- Border radius: 4px (buttons), 8px (cards), 12px (modals), 16px (large containers)
- Sidebar width: 280px (desktop), full-width drawer (mobile)

### Motion Philosophy
- **Micro-interactions**: 150ms ease-out for hovers, button presses
- **Page transitions**: 200ms ease-in-out for route changes
- **Loading states**: Pulse animation (2s infinite) for skeletons
- **Alerts**: Subtle pulse animation to draw attention without distraction
- **Video loading**: Blur-up placeholder with fade-in

### Visual Assets
- **Icons**: Lucide React (consistent, clean line icons)
- **Status indicators**: Custom dot indicators with glow effect
- **Camera thumbnails**: 16:9 aspect ratio, rounded corners
- **Empty states**: Custom illustrations with muted colors
- **Video player**: Custom controls matching the dark theme

---

## Layout & Structure

### Navigation Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  SecureWatch Logo    [Search]              [Notifications] [User]│
├─────────────┬───────────────────────────────────────────────────┤
│             │                                                   │
│  Dashboard  │   ┌─────────────────────────────────────────────┐ │
│  ─────────  │   │                                             │ │
│  Live       │   │              MAIN CONTENT AREA              │ │
│  Cameras    │   │                                             │ │
│  ─────────  │   │     (Dashboard / Camera Grid / Events /     │ │
│  Events     │   │      Settings depending on route)           │ │
│  ─────────  │   │                                             │ │
│  Persons    │   │                                             │ │
│  ─────────  │   │                                             │ │
│  Settings   │   │                                             │ │
│    • Notif. │   │                                             │ │
│    • Storage│   │                                             │ │
│    • System │   └─────────────────────────────────────────────┘ │
│             │                                                   │
│  ─────────  │   ┌─────────────────────────────────────────────┐ │
│  [Collapse] │   │  Status Bar: 4 cameras online | 2 events    │ │
│             │   └─────────────────────────────────────────────┘ │
└─────────────┴───────────────────────────────────────────────────┘
```

### Responsive Strategy
- **Desktop (>1024px)**: Full sidebar, multi-column grid
- **Tablet (768-1024px)**: Collapsible sidebar, 2-column grid
- **Mobile (<768px)**: Bottom navigation, single column, full-width cards

### Page Structure

1. **Dashboard**: 
   - Security status overview (hero card)
   - Recent events (3-5 items)
   - Camera status grid
   - Quick actions

2. **Live Cameras**:
   - Grid view of all cameras
   - Click to expand full-screen
   - Real-time status indicators
   - Quick recording toggle

3. **Events**:
   - Chronological event list
   - Filter by camera, type, date
   - Infinite scroll pagination
   - Bulk actions

4. **Camera Setup**:
   - Step-by-step configuration wizard
   - Connection test
   - Detection zone editor
   - Advanced settings

5. **Settings Pages**:
   - Tabbed interface
   - Grouped preferences
   - Save/Cancel actions

---

## Features & Interactions

### 1. Authentication Flow

**Login Screen**
- Email + password form
- "Remember me" checkbox
- Forgot password link
- Demo mode quick access
- Loading state: Button shows spinner, inputs disabled
- Error: Shake animation, inline error message below field

**Registration**
- Name, email, password, confirm password
- Password strength indicator (real-time)
- Terms acceptance checkbox
- Success: Redirect to dashboard with welcome modal

### 2. Dashboard

**Hero Status Card**
- Current security status (Armed/Armed+AI/Disarmed)
- Toggle to change status
- Last event timestamp
- Overall threat level indicator

**Camera Status Grid**
- 2x2 or 3x3 grid depending on camera count
- Each card shows:
  - Camera name
  - Live thumbnail (updates every 30s)
  - Status dot (green/yellow/red)
  - Quick action buttons (view, record)

**Recent Events Strip**
- Horizontal scrollable list
- Event cards with thumbnail, time, camera name
- Click to view full event

### 3. Live Camera View

**Grid View**
- Camera cards in responsive grid
- Hover: Show camera name overlay, play button
- Click: Open full-screen modal

**Full-Screen View**
- Video fills viewport
- Overlay controls (close, screenshot, record, PTZ)
- Timeline scrubber for recorded footage
- Detection zone overlay toggle
- Close on escape or click outside

### 4. Camera Setup Wizard

**Step 1: Connection**
- Protocol selection (RTSP/ONVIF/CGI)
- IP address input
- Port input (default based on protocol)
- Auto-detect button (ONVIF)

**Step 2: Authentication**
- Username field
- Password field (masked)
- Test connection button
- Success/failure feedback

**Step 3: Configuration**
- Camera name
- Location dropdown
- Channel number (for DVR)
- Stream type (main/sub)

**Step 4: Detection Settings**
- Enable motion detection toggle
- Enable person detection toggle
- Enable face recognition toggle
- Sensitivity slider (1-10)
- Detection zone editor (click to draw)

### 5. Event Detection

**Motion Zones**
- Canvas overlay on camera view
- Draw rectangle zones
- Multiple zones supported
- Color-coded (active=blue, inactive=gray)

**Detection Engine**
- Primary: CP PLUS built-in motion events
- Fallback: Frame differencing via FFmpeg
- AI Enhancement: Person detection via TensorFlow.js/MobileNet
- Face Recognition: Gemini API for face comparison

**Sensitivity Settings**
- Motion threshold (0-100)
- Person confidence (0.5-1.0)
- Minimum event duration (1-30 seconds)
- Cooldown between events (0-5 minutes)

### 6. Video Recording

**Pre-roll Recording**
- Continuous buffer (circular, 30 seconds default)
- On detection: Save buffer + post-roll
- Total clip: 5s pre-roll + up to 30s post-roll

**Recording Storage**
- Local: Server filesystem
- Cloud: S3-compatible storage
- Retention: 7/14/30/90 days

**Clip Metadata**
```typescript
{
  id: string;
  cameraId: string;
  eventId: string;
  startTime: Date;
  endTime: Date;
  duration: number;
  fileSize: number;
  filePath: string;
  thumbnailPath: string;
  type: 'motion' | 'person' | 'face';
  confidence: number;
  personId?: string;
}
```

### 7. Notifications

**Notification Types**
- Motion detected (configurable)
- Person detected (configurable)
- Unknown person detected (configurable)
- Camera offline (always on)
- Storage warning (80%+/90%+ thresholds)

**Notification Content**
- Title: "[Camera Name] - [Event Type]"
- Body: "Motion/Person detected at [Time]"
- Thumbnail: Event thumbnail
- Video: Short clip (if enabled)
- Action: Deep link to event

**Quiet Hours**
- Start time picker
- End time picker
- During quiet hours: Store but don't push
- Exceptions: Unknown person always pushes

### 8. Event History

**Event List**
- Infinite scroll (20 items per page)
- Filters: Camera, Type, Date range, Read/Unread
- Sort: Newest first (default), Oldest first
- Bulk select for delete

**Event Card**
- Thumbnail with play button overlay
- Camera name badge
- Timestamp (relative + absolute)
- Event type badge
- Person name (if recognized)
- Read/Unread indicator

**Event Detail**
- Full video player
- Timeline with detection markers
- Snapshot gallery
- Metadata panel
- Actions: Download, Share, Delete, Mark Read

### 9. Face Recognition

**Known Persons**
- Name field
- Photo upload (multiple)
- Auto-capture from events
- Confidence threshold setting

**Face Registration**
- Upload photo
- AI detects face, shows preview
- Confirm or retry
- Stores embedding vector

**Recognition Flow**
1. Face detected in frame
2. Extract embedding vector
3. Compare with known embeddings
4. If match > threshold: "Hello, [Name]"
5. If match < threshold: "Unknown Person"
6. If no face: Motion/Person event only

### 10. Settings

**Notification Settings**
- Master toggle
- Per-notification-type toggles
- Camera selection (multi-select)
- Quiet hours configuration
- Test notification button

**Storage Settings**
- Storage location display
- Used/Free space bar
- Retention period dropdown
- Auto-cleanup toggle
- Manual cleanup button

**System Settings**
- Change password
- Two-factor authentication (future)
- Session management
- API keys
- Export/Import config

---

## Component Inventory

### Navigation Components

**Sidebar**
- States: Expanded, Collapsed, Mobile drawer
- Active item: Blue background, white text
- Hover: Slate 700 background
- Badge for notification count
- Collapse animation: 200ms ease

**Top Bar**
- Logo left
- Search center (expandable)
- Notifications bell (with count badge)
- User avatar dropdown right

**Mobile Nav**
- Fixed bottom bar
- 5 main items with icons
- Active: Blue icon, others gray

### Form Components

**Input Field**
- States: Default, Focus (blue ring), Error (red ring), Disabled (opacity)
- Label above
- Helper text below
- Error message replaces helper
- Password: Toggle visibility icon

**Select/Dropdown**
- Custom styled to match theme
- Search/filter for long lists
- Multi-select variant
- Loading state for async options

**Toggle Switch**
- States: Off (gray), On (blue), Disabled
- Animated slide
- Optional label left/right

**Slider**
- Single thumb for sensitivity
- Track shows filled portion
- Tooltip shows current value
- Optional tick marks

### Data Display

**Camera Card**
- Thumbnail with gradient overlay
- Status dot (top-right)
- Name overlay (bottom)
- Hover: Scale 1.02, show actions
- Click: Navigate or expand

**Event Card**
- Vertical layout
- Thumbnail top
- Info below
- Click: Navigate to detail
- Long-press: Quick actions (mobile)

**Stats Card**
- Icon left
- Value large
- Label small
- Trend indicator (up/down arrow)
- Click: Navigate to filtered view

### Feedback Components

**Toast Notification**
- Appears top-right
- Auto-dismiss (5s)
- Types: Success, Error, Warning, Info
- Close button
- Progress bar for auto-dismiss

**Modal**
- Centered, max-width based on content
- Backdrop blur
- Close on escape/outside click
- Header, Body, Footer sections
- Sizes: sm (400px), md (560px), lg (720px), full

**Loading States**
- Spinner for buttons
- Skeleton for content
- Pulse for placeholders
- Progress bar for uploads

### Video Components

**Live Player**
- HLS.js for streaming
- Custom controls overlay
- Fullscreen support
- Picture-in-picture support
- Quality selector

**Event Player**
- Video.js based
- Timeline with markers
- Playback speed control
- Screenshot button
- Download button

**Thumbnail**
- Lazy loading
- Blur-up placeholder
- Play icon overlay for videos
- Loading spinner

---

## Technical Approach

### Stack
- **Framework**: Next.js 16 (App Router)
- **Database**: PostgreSQL + Drizzle ORM
- **Auth**: NextAuth.js with credentials provider
- **Styling**: Tailwind CSS
- **State**: React Context + React Query
- **Video**: HLS.js, Video.js
- **AI**: Google Gemini API for face recognition
- **Video Processing**: FFmpeg (via fluent-ffmpeg)
- **Real-time**: WebSocket for live updates
- **Storage**: Local filesystem with configurable path

### API Design

**Authentication**
```
POST   /api/auth/register     - Create account
POST   /api/auth/login       - Login
POST   /api/auth/logout      - Logout
GET    /api/auth/session      - Get current session
POST   /api/auth/reset-password - Password reset request
```

**Cameras**
```
GET    /api/cameras           - List user's cameras
POST   /api/cameras           - Add new camera
GET    /api/cameras/:id       - Get camera details
PUT    /api/cameras/:id       - Update camera
DELETE /api/cameras/:id       - Delete camera
POST   /api/cameras/:id/test  - Test connection
GET    /api/cameras/:id/stream - Get live stream URL
POST   /api/cameras/:id/snapshot - Capture snapshot
```

**Events**
```
GET    /api/events            - List events (paginated)
GET    /api/events/:id        - Get event details
PUT    /api/events/:id        - Update event (mark read)
DELETE /api/events/:id        - Delete event
GET    /api/events/:id/video  - Stream event video
GET    /api/events/:id/download - Download event video
```

**Known Persons**
```
GET    /api/persons           - List known persons
POST   /api/persons           - Add new person
GET    /api/persons/:id       - Get person details
PUT    /api/persons/:id       - Update person
DELETE /api/persons/:id       - Delete person
POST   /api/persons/:id/faces  - Add face to person
DELETE /api/persons/:id/faces/:fid - Remove face
POST   /api/persons/recognize - Recognize face from image
```

**Settings**
```
GET    /api/settings          - Get user settings
PUT    /api/settings          - Update settings
GET    /api/settings/notifications - Get notification settings
PUT    /api/settings/notifications - Update notification settings
GET    /api/settings/storage  - Get storage settings
PUT    /api/settings/storage   - Update storage settings
```

**Detection Webhooks**
```
POST   /api/webhooks/cp-plus  - Receive CP PLUS events
POST   /api/webhooks/ONVIF    - Receive ONVIF events
```

### Data Model

```typescript
// Users
users: {
  id: uuid PK
  email: string UNIQUE
  passwordHash: string
  name: string
  role: 'admin' | 'user'
  avatarUrl: string?
  createdAt: timestamp
  updatedAt: timestamp
}

// Cameras
cameras: {
  id: uuid PK
  userId: uuid FK -> users
  name: string
  ip: string
  port: integer
  username: string (encrypted)
  password: string (encrypted)
  protocol: 'rtsp' | 'onvif' | 'cgi'
  channel: integer
  streamUrl: string?
  status: 'online' | 'offline' | 'error'
  motionEnabled: boolean
  personEnabled: boolean
  faceEnabled: boolean
  sensitivity: integer 1-10
  detectionZones: jsonb
  createdAt: timestamp
  updatedAt: timestamp
}

// Events
events: {
  id: uuid PK
  cameraId: uuid FK -> cameras
  userId: uuid FK -> users
  type: 'motion' | 'person' | 'unknown_face' | 'known_face'
  confidence: decimal
  thumbnailPath: string
  videoPath: string?
  videoDuration: integer?
  metadata: jsonb
  isRead: boolean
  personId: uuid? FK -> knownPersons
  createdAt: timestamp
}

// Known Persons
knownPersons: {
  id: uuid PK
  userId: uuid FK -> users
  name: string
  faces: jsonb[]  // Array of face embeddings/URLs
  confidence: decimal
  createdAt: timestamp
  updatedAt: timestamp
}

// Notification Settings
notificationSettings: {
  id: uuid PK
  userId: uuid FK -> users UNIQUE
  pushEnabled: boolean
  motionEnabled: boolean
  personEnabled: boolean
  unknownEnabled: boolean
  cameraIds: uuid[]
  quietStart: time?
  quietEnd: time?
  updatedAt: timestamp
}

// Storage Settings
storageSettings: {
  id: uuid PK
  userId: uuid FK -> users UNIQUE
  storagePath: string
  retentionDays: integer
  autoCleanup: boolean
  maxStorageGb: integer
  updatedAt: timestamp
}
```

### Security Measures

1. **Credential Encryption**
   - AES-256-GCM for camera passwords
   - Key derived from master password + salt
   - Never log or expose passwords

2. **Authentication**
   - JWT tokens with short expiry
   - Refresh token rotation
   - Password hashing with bcrypt (12 rounds)

3. **API Security**
   - Rate limiting
   - Input validation with Zod
   - SQL injection prevention (Drizzle parameterized queries)
   - XSS prevention (React auto-escaping)

4. **File Security**
   - Video files stored outside web root
   - Signed URLs for video access
   - Automatic deletion after retention period

---

## Video Recording/Event Workflow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          DETECTION & RECORDING WORKFLOW                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌───────────┐  │
│  │   CP PLUS   │     │   Event     │     │  Detection  │     │  Alert    │  │
│  │   DVR/NVR   │────►│   Hook      │────►│   Service   │────►│  Service  │  │
│  │  (Motion)   │     │  (Webhook)  │     │  (Analysis) │     │  (Notify) │  │
│  └─────────────┘     └─────────────┘     └─────────────┘     └───────────┘  │
│         │                                      │                    │       │
│         │                                      │                    │       │
│         ▼                                      ▼                    ▼       │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                        VIDEO RECORDING SERVICE                           │ │
│  │  ┌───────────────┐    ┌───────────────┐    ┌───────────────┐           │ │
│  │  │  Pre-roll     │    │  Clip         │    │  Post-roll    │           │ │
│  │  │  Buffer       │    │  Generator    │    │  Saver        │           │ │
│  │  │  (30s)        │───►│               │───►│  (+15s)       │           │ │
│  │  └───────────────┘    └───────────────┘    └───────────────┘           │ │
│  │          │                                       │                      │ │
│  │          │                                       │                      │ │
│  │          └───────────────┬───────────────────────┘                      │ │
│  │                          │                                               │ │
│  │                          ▼                                               │ │
│  │  ┌─────────────────────────────────────────────────────────────────────┐ │ │
│  │  │                    STORAGE SERVICE                                  │ │ │
│  │  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │ │ │
│  │  │  │  Thumbnails │  │   Videos    │  │  Metadata   │                  │ │ │
│  │  │  │  (/thumbs)  │  │  (/videos)  │  │  (DB)       │                  │ │ │
│  │  │  └─────────────┘  └─────────────┘  └─────────────┘                  │ │ │
│  │  └─────────────────────────────────────────────────────────────────────┘ │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                     │                                        │
│                                     ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                       FACE RECOGNITION (GEMINI)                         │ │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │ │
│  │  │   Face      │  │   Gemini    │  │   Match     │  │   Event     │   │ │
│  │  │   Extract   │─►│   Vision    │─►│   Check     │─►│   Update    │   │ │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │ │
│  │         │                                                       │       │ │
│  │         │ (Unknown)                                              │       │ │
│  │         └───────────────────────────────────────────────────────┘       │ │
│  │                                        │                                 │ │
│  │                                        ▼                                 │ │
│  │                              ┌─────────────┐                            │ │
│  │                              │  Push:       │                            │ │
│  │                              │  "Unknown    │                            │ │
│  │                              │   Person"    │                            │ │
│  │                              └─────────────┘                            │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Complete Implementation Plan

### Phase 1: Foundation (Current Sprint)
- [x] Project setup and configuration
- [x] Database schema design and Drizzle models
- [x] Authentication system (NextAuth)
- [x] API routes structure
- [x] UI component library

### Phase 2: Core Features
- [ ] Camera CRUD operations
- [ ] Live stream viewing (RTSP/HLS)
- [ ] Event detection service
- [ ] Video recording service

### Phase 3: Intelligence
- [ ] Person detection (TensorFlow.js)
- [ ] Face recognition (Gemini)
- [ ] Known persons management
- [ ] Smart notifications

### Phase 4: Polish
- [ ] Real-time updates (WebSocket)
- [ ] Mobile responsive refinements
- [ ] Performance optimization
- [ ] Error handling and edge cases

---

## Demo Data Seed

The application will be seeded with realistic demo data:

### Demo User
- Email: demo@securewatch.com
- Password: Demo123!
- Name: Alex Thompson

### Demo Cameras (4)
1. **Front Gate** - 192.168.1.101 - Online, person detection active
2. **Backyard** - 192.168.1.102 - Online, motion detection active
3. **Garage** - 192.168.1.103 - Online, person detection active
4. **Driveway** - 192.168.1.104 - Offline, needs configuration

### Demo Events (10)
- Mix of motion, person, and unknown face events
- Various times (last 24 hours)
- Some read, some unread
- Associated video clips and thumbnails

### Demo Known Persons (3)
1. **John Thompson** - Homeowner, high confidence
2. **Sarah Thompson** - Family member, medium confidence
3. **Mike Johnson** - Known visitor, high confidence
