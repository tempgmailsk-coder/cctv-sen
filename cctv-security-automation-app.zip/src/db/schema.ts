import { pgTable, uuid, varchar, text, timestamp, boolean, integer, decimal, jsonb, pgEnum } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Enums
export const userRoleEnum = pgEnum('user_role', ['admin', 'user']);
export const cameraStatusEnum = pgEnum('camera_status', ['online', 'offline', 'error']);
export const protocolEnum = pgEnum('protocol', ['rtsp', 'onvif', 'cgi', 'http']);
export const eventTypeEnum = pgEnum('event_type', ['motion', 'person', 'unknown_face', 'known_face']);
export const storageTypeEnum = pgEnum('storage_type', ['local', 'cloud']);

// Users Table
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  role: userRoleEnum('role').default('user').notNull(),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Cameras Table
export const cameras = pgTable('cameras', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  ip: varchar('ip', { length: 45 }).notNull(),
  port: integer('port').default(554).notNull(),
  username: text('username').notNull(), // Encrypted
  password: text('password').notNull(), // Encrypted
  protocol: protocolEnum('protocol').default('rtsp').notNull(),
  channel: integer('channel').default(1).notNull(),
  location: varchar('location', { length: 255 }),
  streamUrl: text('stream_url'),
  status: cameraStatusEnum('status').default('offline').notNull(),
  motionEnabled: boolean('motion_enabled').default(true).notNull(),
  personEnabled: boolean('person_enabled').default(true).notNull(),
  faceEnabled: boolean('face_enabled').default(false).notNull(),
  sensitivity: integer('sensitivity').default(5).notNull(),
  detectionZones: jsonb('detection_zones').default([]),
  thumbnailPath: text('thumbnail_path'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Events Table
export const events = pgTable('events', {
  id: uuid('id').primaryKey().defaultRandom(),
  cameraId: uuid('camera_id').references(() => cameras.id, { onDelete: 'cascade' }).notNull(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  type: eventTypeEnum('event_type').notNull(),
  confidence: decimal('confidence', { precision: 5, scale: 4 }).default('0'),
  thumbnailPath: text('thumbnail_path'),
  videoPath: text('video_path'),
  videoDuration: integer('video_duration'),
  metadata: jsonb('metadata').default({}),
  isRead: boolean('is_read').default(false).notNull(),
  personId: uuid('person_id').references(() => knownPersons.id, { onDelete: 'set null' }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Known Persons Table
export const knownPersons = pgTable('knownPersons', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  faces: jsonb('faces').default([]),
  confidence: decimal('confidence', { precision: 5, scale: 4 }).default('0.8'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Notification Settings Table
export const notificationSettings = pgTable('notificationSettings', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).unique().notNull(),
  pushEnabled: boolean('push_enabled').default(true).notNull(),
  motionEnabled: boolean('motion_enabled').default(true).notNull(),
  personEnabled: boolean('person_enabled').default(true).notNull(),
  unknownEnabled: boolean('unknown_enabled').default(true).notNull(),
  cameraIds: jsonb('camera_ids').default([]),
  quietStart: varchar('quiet_start', { length: 10 }),
  quietEnd: varchar('quiet_end', { length: 10 }),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Storage Settings Table
export const storageSettings = pgTable('storageSettings', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).unique().notNull(),
  storagePath: text('storage_path').default('/storage'),
  retentionDays: integer('retention_days').default(30).notNull(),
  autoCleanup: boolean('auto_cleanup').default(true).notNull(),
  maxStorageGb: integer('max_storage_gb').default(100).notNull(),
  storageUsedGb: decimal('storage_used_gb', { precision: 10, scale: 2 }).default('0'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Sessions Table for NextAuth
export const sessions = pgTable('sessions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  token: varchar('token', { length: 255 }).notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  cameras: many(cameras),
  events: many(events),
  knownPersons: many(knownPersons),
  notificationSettings: many(notificationSettings),
  storageSettings: many(storageSettings),
}));

export const camerasRelations = relations(cameras, ({ one, many }) => ({
  user: one(users, {
    fields: [cameras.userId],
    references: [users.id],
  }),
  events: many(events),
}));

export const eventsRelations = relations(events, ({ one }) => ({
  camera: one(cameras, {
    fields: [events.cameraId],
    references: [cameras.id],
  }),
  user: one(users, {
    fields: [events.userId],
    references: [users.id],
  }),
  person: one(knownPersons, {
    fields: [events.personId],
    references: [knownPersons.id],
  }),
}));

export const knownPersonsRelations = relations(knownPersons, ({ one, many }) => ({
  user: one(users, {
    fields: [knownPersons.userId],
    references: [users.id],
  }),
  events: many(events),
}));
