import { clsx, type ClassValue } from 'clsx';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatDateTime(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

export function formatTime(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

export function formatRelativeTime(date: string | Date): string {
  const d = new Date(date);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(date);
}

export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export function getStatusColor(status: 'online' | 'offline' | 'error'): string {
  switch (status) {
    case 'online':
      return 'text-green-500';
    case 'offline':
      return 'text-slate-500';
    case 'error':
      return 'text-red-500';
  }
}

export function getEventTypeColor(type: 'motion' | 'person' | 'unknown_face' | 'known_face'): string {
  switch (type) {
    case 'motion':
      return 'bg-amber-500/20 text-amber-400';
    case 'person':
      return 'bg-blue-500/20 text-blue-400';
    case 'unknown_face':
      return 'bg-red-500/20 text-red-400';
    case 'known_face':
      return 'bg-green-500/20 text-green-400';
  }
}

export function getEventTypeLabel(type: 'motion' | 'person' | 'unknown_face' | 'known_face'): string {
  switch (type) {
    case 'motion':
      return 'Motion';
    case 'person':
      return 'Person';
    case 'unknown_face':
      return 'Unknown';
    case 'known_face':
      return 'Recognized';
  }
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}
