'use client';

import { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';

// Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  avatarUrl?: string;
}

export interface Camera {
  id: string;
  name: string;
  ip: string;
  port: number;
  protocol: 'rtsp' | 'onvif' | 'cgi' | 'http';
  channel: number;
  location?: string;
  status: 'online' | 'offline' | 'error';
  motionEnabled: boolean;
  personEnabled: boolean;
  faceEnabled: boolean;
  sensitivity: number;
  thumbnailPath?: string;
  createdAt: string;
}

export interface Event {
  id: string;
  cameraId: string;
  cameraName: string;
  type: 'motion' | 'person' | 'unknown_face' | 'known_face';
  confidence: number;
  thumbnailPath?: string;
  videoPath?: string;
  videoDuration?: number;
  metadata: Record<string, unknown>;
  isRead: boolean;
  personId?: string;
  personName?: string;
  createdAt: string;
}

export interface KnownPerson {
  id: string;
  name: string;
  faces: { url: string; embedding?: number[] }[];
  confidence: number;
  eventCount: number;
  lastSeen?: string;
  createdAt: string;
}

export interface NotificationSettings {
  pushEnabled: boolean;
  motionEnabled: boolean;
  personEnabled: boolean;
  unknownEnabled: boolean;
  cameraIds: string[];
  quietStart?: string;
  quietEnd?: string;
}

export interface StorageSettings {
  storagePath: string;
  retentionDays: number;
  autoCleanup: boolean;
  maxStorageGb: number;
  storageUsedGb: number;
}

export interface DashboardStats {
  totalCameras: number;
  onlineCameras: number;
  todayEvents: number;
  unreadEvents: number;
  storageUsed: number;
}

// State
interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  cameras: Camera[];
  events: Event[];
  knownPersons: KnownPerson[];
  dashboardStats: DashboardStats;
  notificationSettings: NotificationSettings;
  storageSettings: StorageSettings;
  sidebarCollapsed: boolean;
}

// Actions
type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_AUTHENTICATED'; payload: boolean }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_CAMERAS'; payload: Camera[] }
  | { type: 'ADD_CAMERA'; payload: Camera }
  | { type: 'UPDATE_CAMERA'; payload: Camera }
  | { type: 'DELETE_CAMERA'; payload: string }
  | { type: 'SET_EVENTS'; payload: Event[] }
  | { type: 'ADD_EVENT'; payload: Event }
  | { type: 'UPDATE_EVENT'; payload: Event }
  | { type: 'DELETE_EVENT'; payload: string }
  | { type: 'SET_KNOWN_PERSONS'; payload: KnownPerson[] }
  | { type: 'ADD_KNOWN_PERSON'; payload: KnownPerson }
  | { type: 'UPDATE_KNOWN_PERSON'; payload: KnownPerson }
  | { type: 'DELETE_KNOWN_PERSON'; payload: string }
  | { type: 'SET_DASHBOARD_STATS'; payload: DashboardStats }
  | { type: 'SET_NOTIFICATION_SETTINGS'; payload: NotificationSettings }
  | { type: 'SET_STORAGE_SETTINGS'; payload: StorageSettings }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'INIT_STATE'; payload: Partial<AppState> };

// Initial State
const initialState: AppState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  cameras: [],
  events: [],
  knownPersons: [],
  dashboardStats: {
    totalCameras: 0,
    onlineCameras: 0,
    todayEvents: 0,
    unreadEvents: 0,
    storageUsed: 0,
  },
  notificationSettings: {
    pushEnabled: true,
    motionEnabled: true,
    personEnabled: true,
    unknownEnabled: true,
    cameraIds: [],
    quietStart: undefined,
    quietEnd: undefined,
  },
  storageSettings: {
    storagePath: '/storage',
    retentionDays: 30,
    autoCleanup: true,
    maxStorageGb: 100,
    storageUsedGb: 0,
  },
  sidebarCollapsed: false,
};

// Reducer
function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_AUTHENTICATED':
      return { ...state, isAuthenticated: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_CAMERAS':
      return { ...state, cameras: action.payload };
    case 'ADD_CAMERA':
      return { ...state, cameras: [...state.cameras, action.payload] };
    case 'UPDATE_CAMERA':
      return {
        ...state,
        cameras: state.cameras.map((c) =>
          c.id === action.payload.id ? action.payload : c
        ),
      };
    case 'DELETE_CAMERA':
      return {
        ...state,
        cameras: state.cameras.filter((c) => c.id !== action.payload),
      };
    case 'SET_EVENTS':
      return { ...state, events: action.payload };
    case 'ADD_EVENT':
      return { ...state, events: [action.payload, ...state.events] };
    case 'UPDATE_EVENT':
      return {
        ...state,
        events: state.events.map((e) =>
          e.id === action.payload.id ? action.payload : e
        ),
      };
    case 'DELETE_EVENT':
      return {
        ...state,
        events: state.events.filter((e) => e.id !== action.payload),
      };
    case 'SET_KNOWN_PERSONS':
      return { ...state, knownPersons: action.payload };
    case 'ADD_KNOWN_PERSON':
      return { ...state, knownPersons: [...state.knownPersons, action.payload] };
    case 'UPDATE_KNOWN_PERSON':
      return {
        ...state,
        knownPersons: state.knownPersons.map((p) =>
          p.id === action.payload.id ? action.payload : p
        ),
      };
    case 'DELETE_KNOWN_PERSON':
      return {
        ...state,
        knownPersons: state.knownPersons.filter((p) => p.id !== action.payload),
      };
    case 'SET_DASHBOARD_STATS':
      return { ...state, dashboardStats: action.payload };
    case 'SET_NOTIFICATION_SETTINGS':
      return { ...state, notificationSettings: action.payload };
    case 'SET_STORAGE_SETTINGS':
      return { ...state, storageSettings: action.payload };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarCollapsed: !state.sidebarCollapsed };
    case 'INIT_STATE':
      return { ...state, ...action.payload };
    default:
      return state;
  }
}

// Context
interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshCameras: () => Promise<void>;
  refreshEvents: () => Promise<void>;
  refreshKnownPersons: () => Promise<void>;
  refreshDashboard: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Demo data for initial state
const demoUser: User = {
  id: 'demo-user-id',
  email: 'demo@securewatch.com',
  name: 'Alex Thompson',
  role: 'admin',
};

const demoCameras: Camera[] = [
  {
    id: 'cam-1',
    name: 'Front Gate',
    ip: '192.168.1.101',
    port: 554,
    protocol: 'rtsp',
    channel: 1,
    location: 'Entrance',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: true,
    sensitivity: 7,
    createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'cam-2',
    name: 'Backyard',
    ip: '192.168.1.102',
    port: 554,
    protocol: 'rtsp',
    channel: 2,
    location: 'Garden',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: false,
    sensitivity: 5,
    createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'cam-3',
    name: 'Garage',
    ip: '192.168.1.103',
    port: 554,
    protocol: 'rtsp',
    channel: 3,
    location: 'Garage',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: false,
    sensitivity: 6,
    createdAt: '2024-01-15T10:00:00Z',
  },
  {
    id: 'cam-4',
    name: 'Driveway',
    ip: '192.168.1.104',
    port: 554,
    protocol: 'rtsp',
    channel: 4,
    location: 'Driveway',
    status: 'offline',
    motionEnabled: false,
    personEnabled: false,
    faceEnabled: false,
    sensitivity: 5,
    createdAt: '2024-01-15T10:00:00Z',
  },
];

const demoEvents: Event[] = [
  {
    id: 'evt-1',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'person',
    confidence: 0.95,
    thumbnailPath: '/thumbnails/evt-1.jpg',
    videoPath: '/videos/evt-1.mp4',
    videoDuration: 20,
    metadata: { duration: 20, peakConfidence: 0.97 },
    isRead: false,
    personName: 'John Thompson',
    createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
  },
  {
    id: 'evt-2',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'unknown_face',
    confidence: 0.72,
    thumbnailPath: '/thumbnails/evt-2.jpg',
    videoPath: '/videos/evt-2.mp4',
    videoDuration: 15,
    metadata: { duration: 15, peakConfidence: 0.75 },
    isRead: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
  {
    id: 'evt-3',
    cameraId: 'cam-2',
    cameraName: 'Backyard',
    type: 'motion',
    confidence: 0.65,
    thumbnailPath: '/thumbnails/evt-3.jpg',
    videoPath: '/videos/evt-3.mp4',
    videoDuration: 12,
    metadata: { duration: 12, peakConfidence: 0.68 },
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'evt-4',
    cameraId: 'cam-3',
    cameraName: 'Garage',
    type: 'person',
    confidence: 0.91,
    thumbnailPath: '/thumbnails/evt-4.jpg',
    videoPath: '/videos/evt-4.mp4',
    videoDuration: 18,
    metadata: { duration: 18, peakConfidence: 0.93 },
    isRead: true,
    personName: 'Sarah Thompson',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
  },
  {
    id: 'evt-5',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'known_face',
    confidence: 0.88,
    thumbnailPath: '/thumbnails/evt-5.jpg',
    videoPath: '/videos/evt-5.mp4',
    videoDuration: 22,
    metadata: { duration: 22, peakConfidence: 0.9 },
    isRead: true,
    personName: 'Mike Johnson',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString(),
  },
  {
    id: 'evt-6',
    cameraId: 'cam-2',
    cameraName: 'Backyard',
    type: 'motion',
    confidence: 0.55,
    thumbnailPath: '/thumbnails/evt-6.jpg',
    videoPath: '/videos/evt-6.mp4',
    videoDuration: 8,
    metadata: { duration: 8, peakConfidence: 0.6 },
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
  },
  {
    id: 'evt-7',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'person',
    confidence: 0.94,
    thumbnailPath: '/thumbnails/evt-7.jpg',
    videoPath: '/videos/evt-7.mp4',
    videoDuration: 25,
    metadata: { duration: 25, peakConfidence: 0.96 },
    isRead: true,
    personName: 'John Thompson',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString(),
  },
  {
    id: 'evt-8',
    cameraId: 'cam-3',
    cameraName: 'Garage',
    type: 'unknown_face',
    confidence: 0.68,
    thumbnailPath: '/thumbnails/evt-8.jpg',
    videoPath: '/videos/evt-8.mp4',
    videoDuration: 14,
    metadata: { duration: 14, peakConfidence: 0.7 },
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
  },
];

const demoKnownPersons: KnownPerson[] = [
  {
    id: 'person-1',
    name: 'John Thompson',
    faces: [
      { url: '/faces/john-1.jpg' },
      { url: '/faces/john-2.jpg' },
    ],
    confidence: 0.92,
    eventCount: 45,
    lastSeen: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'person-2',
    name: 'Sarah Thompson',
    faces: [
      { url: '/faces/sarah-1.jpg' },
    ],
    confidence: 0.88,
    eventCount: 32,
    lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
    createdAt: '2024-01-05T00:00:00Z',
  },
  {
    id: 'person-3',
    name: 'Mike Johnson',
    faces: [
      { url: '/faces/mike-1.jpg' },
      { url: '/faces/mike-2.jpg' },
    ],
    confidence: 0.9,
    eventCount: 12,
    lastSeen: new Date(Date.now() - 1000 * 60 * 60 * 8).toISOString(),
    createdAt: '2024-01-10T00:00:00Z',
  },
];

// Provider
export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Initialize with demo data on mount
  useEffect(() => {
    const initDemo = async () => {
      // Simulate loading
      await new Promise((resolve) => setTimeout(resolve, 500));
      
      dispatch({
        type: 'INIT_STATE',
        payload: {
          user: demoUser,
          isAuthenticated: true,
          isLoading: false,
          cameras: demoCameras,
          events: demoEvents,
          knownPersons: demoKnownPersons,
          dashboardStats: {
            totalCameras: 4,
            onlineCameras: 3,
            todayEvents: 5,
            unreadEvents: 2,
            storageUsed: 23.5,
          },
          notificationSettings: {
            pushEnabled: true,
            motionEnabled: true,
            personEnabled: true,
            unknownEnabled: true,
            cameraIds: ['cam-1', 'cam-2', 'cam-3'],
            quietStart: '22:00',
            quietEnd: '07:00',
          },
          storageSettings: {
            storagePath: '/storage',
            retentionDays: 30,
            autoCleanup: true,
            maxStorageGb: 100,
            storageUsedGb: 23.5,
          },
        },
      });
    };

    initDemo();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      // Demo login
      if (email === 'demo@securewatch.com' || email === 'demo') {
        dispatch({
          type: 'INIT_STATE',
          payload: {
            user: demoUser,
            isAuthenticated: true,
            isLoading: false,
            cameras: demoCameras,
            events: demoEvents,
            knownPersons: demoKnownPersons,
            dashboardStats: {
              totalCameras: 4,
              onlineCameras: 3,
              todayEvents: 5,
              unreadEvents: 2,
              storageUsed: 23.5,
            },
          },
        });
        return { success: true };
      }
      
      // For demo, accept any login
      const user: User = {
        id: 'user-' + Date.now(),
        email,
        name: email.split('@')[0],
        role: 'user',
      };
      
      dispatch({
        type: 'INIT_STATE',
        payload: {
          user,
          isAuthenticated: true,
          isLoading: false,
          cameras: demoCameras,
          events: demoEvents,
          knownPersons: demoKnownPersons,
          dashboardStats: {
            totalCameras: 4,
            onlineCameras: 3,
            todayEvents: 5,
            unreadEvents: 2,
            storageUsed: 23.5,
          },
        },
      });
      
      return { success: true };
    } catch {
      return { success: false, error: 'Invalid credentials' };
    }
  };

  const register = async (name: string, email: string, password: string) => {
    try {
      const user: User = {
        id: 'user-' + Date.now(),
        email,
        name,
        role: 'user',
      };
      
      dispatch({
        type: 'INIT_STATE',
        payload: {
          user,
          isAuthenticated: true,
          isLoading: false,
          cameras: [],
          events: [],
          knownPersons: [],
          dashboardStats: {
            totalCameras: 0,
            onlineCameras: 0,
            todayEvents: 0,
            unreadEvents: 0,
            storageUsed: 0,
          },
        },
      });
      
      return { success: true };
    } catch {
      return { success: false, error: 'Registration failed' };
    }
  };

  const logout = async () => {
    dispatch({ type: 'SET_LOADING', payload: true });
    await new Promise((resolve) => setTimeout(resolve, 300));
    dispatch({
      type: 'INIT_STATE',
      payload: {
        user: null,
        isAuthenticated: false,
        isLoading: false,
        cameras: [],
        events: [],
        knownPersons: [],
        dashboardStats: {
          totalCameras: 0,
          onlineCameras: 0,
          todayEvents: 0,
          unreadEvents: 0,
          storageUsed: 0,
        },
      },
    });
  };

  const refreshCameras = async () => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    dispatch({ type: 'SET_CAMERAS', payload: demoCameras });
  };

  const refreshEvents = async () => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    dispatch({ type: 'SET_EVENTS', payload: demoEvents });
  };

  const refreshKnownPersons = async () => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    dispatch({ type: 'SET_KNOWN_PERSONS', payload: demoKnownPersons });
  };

  const refreshDashboard = async () => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    dispatch({
      type: 'SET_DASHBOARD_STATS',
      payload: {
        totalCameras: 4,
        onlineCameras: 3,
        todayEvents: 5,
        unreadEvents: 2,
        storageUsed: 23.5,
      },
    });
  };

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        login,
        register,
        logout,
        refreshCameras,
        refreshEvents,
        refreshKnownPersons,
        refreshDashboard,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

// Hook
export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
