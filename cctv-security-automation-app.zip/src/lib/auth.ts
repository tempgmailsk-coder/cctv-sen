import crypto from 'crypto';

// AES-256-GCM encryption for sensitive data
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;
const SALT_LENGTH = 32;
const KEY_LENGTH = 32;
const MASTER_KEY = process.env.ENCRYPTION_KEY || 'default-master-key-change-in-production!';

// Derive key from master key
function deriveKey(salt: Buffer): Buffer {
  return crypto.pbkdf2Sync(MASTER_KEY, salt, 100000, KEY_LENGTH, 'sha256');
}

// Encrypt function
export function encrypt(plaintext: string): string {
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = deriveKey(salt);
  
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  
  let encrypted = cipher.update(plaintext, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const tag = cipher.getAuthTag();
  
  // Combine salt + iv + tag + encrypted data
  return salt.toString('hex') + iv.toString('hex') + tag.toString('hex') + encrypted;
}

// Decrypt function
export function decrypt(ciphertext: string): string {
  const salt = Buffer.from(ciphertext.slice(0, SALT_LENGTH * 2), 'hex');
  const iv = Buffer.from(ciphertext.slice(SALT_LENGTH * 2, (SALT_LENGTH + IV_LENGTH) * 2), 'hex');
  const tag = Buffer.from(ciphertext.slice((SALT_LENGTH + IV_LENGTH) * 2, (SALT_LENGTH + IV_LENGTH + TAG_LENGTH) * 2), 'hex');
  const encrypted = ciphertext.slice((SALT_LENGTH + IV_LENGTH + TAG_LENGTH) * 2);
  
  const key = deriveKey(salt);
  
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

// Hash password with bcrypt-like approach using native crypto
export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

// Verify password
export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  const [salt, hash] = storedHash.split(':');
  const verifyHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(verifyHash));
}

// Generate JWT-like token (simplified for demo - use real JWT in production)
export function generateToken(userId: string): string {
  const payload = {
    userId,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
    iat: Date.now(),
  };
  const base64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto.createHmac('sha256', process.env.JWT_SECRET || 'jwt-secret-key')
    .update(base64)
    .digest('base64url');
  return `${base64}.${signature}`;
}

// Verify token
export function verifyToken(token: string): { userId: string } | null {
  try {
    const [base64, signature] = token.split('.');
    const expectedSignature = crypto.createHmac('sha256', process.env.JWT_SECRET || 'jwt-secret-key')
      .update(base64)
      .digest('base64url');
    
    if (signature !== expectedSignature) return null;
    
    const payload = JSON.parse(Buffer.from(base64, 'base64url').toString());
    
    if (payload.exp < Date.now()) return null;
    
    return { userId: payload.userId };
  } catch {
    return null;
  }
}

// Mask sensitive data for logging
export function maskSensitiveData(data: Record<string, unknown>): Record<string, unknown> {
  const sensitiveKeys = ['password', 'username', 'ip', 'streamUrl', 'token', 'secret'];
  const masked: Record<string, unknown> = {};
  
  for (const [key, value] of Object.entries(data)) {
    if (sensitiveKeys.some(sk => key.toLowerCase().includes(sk.toLowerCase()))) {
      masked[key] = typeof value === 'string' && value.length > 4 
        ? `${value.slice(0, 2)}${'*'.repeat(value.length - 4)}${value.slice(-2)}`
        : '***';
    } else if (typeof value === 'object' && value !== null) {
      masked[key] = maskSensitiveData(value as Record<string, unknown>);
    } else {
      masked[key] = value;
    }
  }
  
  return masked;
}
