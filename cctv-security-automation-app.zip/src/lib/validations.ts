import { z } from 'zod';

// Auth Validations
export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  rememberMe: z.boolean().optional(),
});

export const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  password: z.string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

// Camera Validations
export const cameraSchema = z.object({
  name: z.string().min(1, 'Camera name is required'),
  ip: z.string().regex(/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/, 'Invalid IP address'),
  port: z.number().min(1).max(65535),
  username: z.string().min(1, 'Username is required'),
  password: z.string().min(1, 'Password is required'),
  protocol: z.enum(['rtsp', 'onvif', 'cgi', 'http']),
  channel: z.number().min(1).max(32),
  location: z.string().optional(),
  motionEnabled: z.boolean().default(true),
  personEnabled: z.boolean().default(true),
  faceEnabled: z.boolean().default(false),
  sensitivity: z.number().min(1).max(10).default(5),
  detectionZones: z.array(z.object({
    x: z.number(),
    y: z.number(),
    width: z.number(),
    height: z.number(),
  })).default([]),
});

export const cameraUpdateSchema = cameraSchema.partial();

// Event Validations
export const eventQuerySchema = z.object({
  cameraId: z.string().uuid().optional(),
  type: z.enum(['motion', 'person', 'unknown_face', 'known_face']).optional(),
  isRead: z.boolean().optional(),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  page: z.number().min(1).default(1),
  limit: z.number().min(1).max(100).default(20),
});

// Known Person Validations
export const knownPersonSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  confidence: z.number().min(0.5).max(1).default(0.8),
  faces: z.array(z.object({
    url: z.string().url(),
    embedding: z.array(z.number()).optional(),
  })).default([]),
});

export const knownPersonUpdateSchema = knownPersonSchema.partial();

// Settings Validations
export const notificationSettingsSchema = z.object({
  pushEnabled: z.boolean(),
  motionEnabled: z.boolean(),
  personEnabled: z.boolean(),
  unknownEnabled: z.boolean(),
  cameraIds: z.array(z.string().uuid()).default([]),
  quietStart: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().nullable(),
  quietEnd: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/).optional().nullable(),
});

export const storageSettingsSchema = z.object({
  storagePath: z.string().min(1),
  retentionDays: z.number().min(1).max(365),
  autoCleanup: z.boolean(),
  maxStorageGb: z.number().min(1).max(1000),
});

// Types
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
export type CameraInput = z.infer<typeof cameraSchema>;
export type CameraUpdateInput = z.infer<typeof cameraUpdateSchema>;
export type EventQueryInput = z.infer<typeof eventQuerySchema>;
export type KnownPersonInput = z.infer<typeof knownPersonSchema>;
export type KnownPersonUpdateInput = z.infer<typeof knownPersonUpdateSchema>;
export type NotificationSettingsInput = z.infer<typeof notificationSettingsSchema>;
export type StorageSettingsInput = z.infer<typeof storageSettingsSchema>;
