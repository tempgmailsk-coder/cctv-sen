import { NextRequest, NextResponse } from 'next/server';

// Demo camera data
const cameras = [
  {
    id: 'cam-1',
    name: 'Front Gate',
    ip: '192.168.1.101',
    port: 554,
    protocol: 'rtsp',
    channel: 1,
    location: 'Entrance',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: true,
    sensitivity: 7,
  },
  {
    id: 'cam-2',
    name: 'Backyard',
    ip: '192.168.1.102',
    port: 554,
    protocol: 'rtsp',
    channel: 2,
    location: 'Garden',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: false,
    sensitivity: 5,
  },
  {
    id: 'cam-3',
    name: 'Garage',
    ip: '192.168.1.103',
    port: 554,
    protocol: 'rtsp',
    channel: 3,
    location: 'Garage',
    status: 'online',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: false,
    sensitivity: 6,
  },
  {
    id: 'cam-4',
    name: 'Driveway',
    ip: '192.168.1.104',
    port: 554,
    protocol: 'rtsp',
    channel: 4,
    location: 'Driveway',
    status: 'offline',
    motionEnabled: false,
    personEnabled: false,
    faceEnabled: false,
    sensitivity: 5,
  },
];

export async function GET() {
  return NextResponse.json({
    success: true,
    data: cameras,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    if (!body.name || !body.ip || !body.username || !body.password) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Create new camera
    const newCamera = {
      id: `cam-${Date.now()}`,
      name: body.name,
      ip: body.ip,
      port: body.port || 554,
      protocol: body.protocol || 'rtsp',
      channel: body.channel || 1,
      location: body.location,
      status: 'online',
      motionEnabled: body.motionEnabled ?? true,
      personEnabled: body.personEnabled ?? true,
      faceEnabled: body.faceEnabled ?? false,
      sensitivity: body.sensitivity ?? 5,
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: newCamera,
    }, { status: 201 });
  } catch {
    return NextResponse.json(
      { success: false, error: 'Invalid request body' },
      { status: 400 }
    );
  }
}
