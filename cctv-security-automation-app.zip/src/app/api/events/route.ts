import { NextRequest, NextResponse } from 'next/server';

// Demo events data
const events = [
  {
    id: 'evt-1',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'person',
    confidence: 0.95,
    thumbnailPath: '/thumbnails/evt-1.jpg',
    videoPath: '/videos/evt-1.mp4',
    videoDuration: 20,
    metadata: { duration: 20, peakConfidence: 0.97 },
    isRead: false,
    personName: 'John Thompson',
    createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
  },
  {
    id: 'evt-2',
    cameraId: 'cam-1',
    cameraName: 'Front Gate',
    type: 'unknown_face',
    confidence: 0.72,
    thumbnailPath: '/thumbnails/evt-2.jpg',
    videoPath: '/videos/evt-2.mp4',
    videoDuration: 15,
    metadata: { duration: 15, peakConfidence: 0.75 },
    isRead: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
  },
  {
    id: 'evt-3',
    cameraId: 'cam-2',
    cameraName: 'Backyard',
    type: 'motion',
    confidence: 0.65,
    thumbnailPath: '/thumbnails/evt-3.jpg',
    videoPath: '/videos/evt-3.mp4',
    videoDuration: 12,
    metadata: { duration: 12, peakConfidence: 0.68 },
    isRead: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
  },
  {
    id: 'evt-4',
    cameraId: 'cam-3',
    cameraName: 'Garage',
    type: 'person',
    confidence: 0.91,
    thumbnailPath: '/thumbnails/evt-4.jpg',
    videoPath: '/videos/evt-4.mp4',
    videoDuration: 18,
    metadata: { duration: 18, peakConfidence: 0.93 },
    isRead: true,
    personName: 'Sarah Thompson',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(),
  },
];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const cameraId = searchParams.get('cameraId');
  const type = searchParams.get('type');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  let filteredEvents = [...events];

  if (cameraId) {
    filteredEvents = filteredEvents.filter(e => e.cameraId === cameraId);
  }

  if (type) {
    filteredEvents = filteredEvents.filter(e => e.type === type);
  }

  // Pagination
  const startIndex = (page - 1) * limit;
  const paginatedEvents = filteredEvents.slice(startIndex, startIndex + limit);

  return NextResponse.json({
    success: true,
    data: paginatedEvents,
    pagination: {
      page,
      limit,
      total: filteredEvents.length,
      totalPages: Math.ceil(filteredEvents.length / limit),
    },
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    if (!body.cameraId || !body.type) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Create new event
    const newEvent = {
      id: `evt-${Date.now()}`,
      cameraId: body.cameraId,
      cameraName: body.cameraName || 'Unknown Camera',
      type: body.type,
      confidence: body.confidence || 0,
      thumbnailPath: body.thumbnailPath,
      videoPath: body.videoPath,
      videoDuration: body.videoDuration,
      metadata: body.metadata || {},
      isRead: false,
      personId: body.personId,
      personName: body.personName,
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json({
      success: true,
      data: newEvent,
    }, { status: 201 });
  } catch {
    return NextResponse.json(
      { success: false, error: 'Invalid request body' },
      { status: 400 }
    );
  }
}
