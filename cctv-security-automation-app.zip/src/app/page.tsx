import DashboardStats from "@/components/DashboardStats";

export default function HomePage() {
  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 mt-1">Welcome back! Here&apos;s your security overview.</p>
      </div>
      <DashboardStats />
    </div>
  );
}
