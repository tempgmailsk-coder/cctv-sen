'use client';

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { 
  Bell,
  BellOff,
  Smartphone,
  Clock,
  Video,
  User,
  AlertTriangle,
  Check,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function NotificationSettingsPage() {
  const { state, dispatch } = useApp();
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  const settings = state.notificationSettings;
  const cameras = state.cameras;

  const updateSetting = <K extends keyof typeof settings>(key: K, value: typeof settings[K]) => {
    dispatch({
      type: 'SET_NOTIFICATION_SETTINGS',
      payload: { ...settings, [key]: value },
    });
    setSaved(false);
  };

  const toggleCamera = (cameraId: string) => {
    const newCameraIds = settings.cameraIds.includes(cameraId)
      ? settings.cameraIds.filter(id => id !== cameraId)
      : [...settings.cameraIds, cameraId];
    updateSetting('cameraIds', newCameraIds);
  };

  const handleSave = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    setLoading(false);
    setSaved(true);
  };

  const handleTestNotification = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setLoading(false);
    alert('Test notification sent! Check your device.');
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Notification Settings</h1>
        <p className="text-slate-400 mt-1">Configure how and when you receive alerts</p>
      </div>

      {/* Master Toggle */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={cn(
              'w-12 h-12 rounded-xl flex items-center justify-center transition-colors',
              settings.pushEnabled ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-700 text-slate-500'
            )}>
              {settings.pushEnabled ? (
                <Bell className="w-6 h-6" />
              ) : (
                <BellOff className="w-6 h-6" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Push Notifications</h2>
              <p className="text-sm text-slate-400">
                {settings.pushEnabled ? 'Notifications are enabled' : 'Notifications are disabled'}
              </p>
            </div>
          </div>
          <button
            onClick={() => updateSetting('pushEnabled', !settings.pushEnabled)}
            className={cn(
              'relative w-14 h-7 rounded-full transition-colors',
              settings.pushEnabled ? 'bg-blue-500' : 'bg-slate-600'
            )}
          >
            <span className={cn(
              'absolute top-1 w-5 h-5 rounded-full bg-white transition-transform',
              settings.pushEnabled ? 'left-8' : 'left-1'
            )} />
          </button>
        </div>
      </div>

      {/* Notification Types */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Notification Types</h2>
        <p className="text-sm text-slate-400 mb-4">
          Choose which events trigger notifications
        </p>

        <div className="space-y-4">
          <NotificationToggle
            icon={Video}
            label="Motion Detection"
            description="Get notified when motion is detected"
            checked={settings.motionEnabled}
            onChange={(v) => updateSetting('motionEnabled', v)}
            disabled={!settings.pushEnabled}
          />
          <NotificationToggle
            icon={User}
            label="Person Detection"
            description="Get notified when a person is detected"
            checked={settings.personEnabled}
            onChange={(v) => updateSetting('personEnabled', v)}
            disabled={!settings.pushEnabled}
          />
          <NotificationToggle
            icon={AlertTriangle}
            label="Unknown Person"
            description="Get notified when an unrecognized face is detected"
            checked={settings.unknownEnabled}
            onChange={(v) => updateSetting('unknownEnabled', v)}
            disabled={!settings.pushEnabled}
          />
        </div>
      </div>

      {/* Camera Selection */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Camera Notifications</h2>
        <p className="text-sm text-slate-400 mb-4">
          Select which cameras can send notifications
        </p>

        <div className="space-y-3">
          {cameras.map((camera) => (
            <div
              key={camera.id}
              className={cn(
                'flex items-center justify-between p-4 rounded-xl transition-colors',
                settings.cameraIds.includes(camera.id) 
                  ? 'bg-blue-500/10 border border-blue-500/30' 
                  : 'bg-slate-900/50 border border-slate-700'
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  'w-10 h-10 rounded-lg flex items-center justify-center',
                  camera.status === 'online' ? 'bg-green-500/20 text-green-400' : 'bg-slate-700 text-slate-500'
                )}>
                  <Video className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-medium text-white">{camera.name}</p>
                  <p className="text-xs text-slate-500">
                    {camera.status === 'online' ? 'Online' : 'Offline'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => toggleCamera(camera.id)}
                disabled={!settings.pushEnabled}
                className={cn(
                  'relative w-12 h-6 rounded-full transition-colors',
                  settings.cameraIds.includes(camera.id) ? 'bg-blue-500' : 'bg-slate-600',
                  !settings.pushEnabled && 'opacity-50 cursor-not-allowed'
                )}
              >
                <span className={cn(
                  'absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform',
                  settings.cameraIds.includes(camera.id) ? 'left-6' : 'left-0.5'
                )} />
              </button>
            </div>
          ))}
        </div>

        <div className="mt-4 flex gap-3">
          <button
            onClick={() => updateSetting('cameraIds', cameras.map(c => c.id))}
            className="text-sm text-blue-400 hover:text-blue-300"
          >
            Select all cameras
          </button>
          <span className="text-slate-600">|</span>
          <button
            onClick={() => updateSetting('cameraIds', [])}
            className="text-sm text-slate-400 hover:text-slate-300"
          >
            Clear selection
          </button>
        </div>
      </div>

      {/* Quiet Hours */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Clock className="w-5 h-5 text-slate-400" />
          <div>
            <h2 className="text-lg font-semibold text-white">Quiet Hours</h2>
            <p className="text-sm text-slate-400">
              Disable notifications during specified hours
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">
              Start Time
            </label>
            <input
              type="time"
              value={settings.quietStart || ''}
              onChange={(e) => updateSetting('quietStart', e.target.value || undefined)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">
              End Time
            </label>
            <input
              type="time"
              value={settings.quietEnd || ''}
              onChange={(e) => updateSetting('quietEnd', e.target.value || undefined)}
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <p className="text-xs text-slate-500 mt-3">
          During quiet hours, notifications will be stored but not pushed. 
          Unknown person alerts will still be sent immediately.
        </p>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={handleTestNotification}
          disabled={!settings.pushEnabled || loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white rounded-lg transition-colors"
        >
          <Smartphone className="w-4 h-4" />
          Test Notification
        </button>
        <div className="flex items-center gap-3">
          {saved && (
            <span className="text-sm text-green-400 flex items-center gap-1">
              <Check className="w-4 h-4" />
              Saved
            </span>
          )}
          <button
            onClick={handleSave}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-medium rounded-lg transition-colors"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

function NotificationToggle({ 
  icon: Icon,
  label,
  description,
  checked,
  onChange,
  disabled
}: {
  icon: React.ElementType;
  label: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className={cn(
      'flex items-center justify-between p-4 rounded-xl transition-colors',
      checked ? 'bg-blue-500/10 border border-blue-500/30' : 'bg-slate-900/50 border border-slate-700',
      disabled && 'opacity-50'
    )}>
      <div className="flex items-center gap-3">
        <Icon className={cn(
          'w-5 h-5',
          checked ? 'text-blue-400' : 'text-slate-500'
        )} />
        <div>
          <p className="font-medium text-white">{label}</p>
          <p className="text-xs text-slate-500">{description}</p>
        </div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        disabled={disabled}
        className={cn(
          'relative w-12 h-6 rounded-full transition-colors',
          checked ? 'bg-blue-500' : 'bg-slate-600',
          disabled && 'cursor-not-allowed'
        )}
      >
        <span className={cn(
          'absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform',
          checked ? 'left-6' : 'left-0.5'
        )} />
      </button>
    </div>
  );
}
