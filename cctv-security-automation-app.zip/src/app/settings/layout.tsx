'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { 
  Bell,
  HardDrive,
  Settings,
  Shield
} from 'lucide-react';

const settingsNav = [
  { name: 'Notifications', href: '/settings/notifications', icon: Bell },
  { name: 'Storage', href: '/settings/storage', icon: HardDrive },
  { name: 'System', href: '/settings/system', icon: Settings },
];

export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex gap-6">
      {/* Settings Sidebar */}
      <div className="hidden lg:block w-64 flex-shrink-0">
        <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-4 sticky top-20">
          <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4 px-3">
            Settings
          </h2>
          <nav className="space-y-1">
            {settingsNav.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                    isActive
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'text-slate-400 hover:bg-slate-700/50 hover:text-white'
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.name}
                </Link>
              );
            })}
          </nav>

          <div className="mt-8 pt-4 border-t border-slate-700/50">
            <div className="px-3 py-2">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Shield className="w-4 h-4" />
                <span>Your data is encrypted</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Content */}
      <div className="flex-1 min-w-0">
        {children}
      </div>
    </div>
  );
}
