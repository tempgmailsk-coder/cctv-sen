'use client';

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { 
  HardDrive,
  Clock,
  Trash2,
  FolderOpen,
  AlertTriangle,
  Check,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { cn, formatBytes } from '@/lib/utils';

export default function StorageSettingsPage() {
  const { state, dispatch } = useApp();
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [cleaning, setCleaning] = useState(false);

  const settings = state.storageSettings;
  const storageUsedGb = state.dashboardStats.storageUsed;
  const storagePercent = (storageUsedGb / settings.maxStorageGb) * 100;

  const updateSetting = <K extends keyof typeof settings>(key: K, value: typeof settings[K]) => {
    dispatch({
      type: 'SET_STORAGE_SETTINGS',
      payload: { ...settings, [key]: value },
    });
    setSaved(false);
  };

  const handleSave = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    setLoading(false);
    setSaved(true);
  };

  const handleCleanup = async () => {
    setCleaning(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    dispatch({
      type: 'SET_DASHBOARD_STATS',
      payload: { ...state.dashboardStats, storageUsed: 5.2 },
    });
    setCleaning(false);
  };

  const getStorageColor = () => {
    if (storagePercent >= 90) return 'bg-red-500';
    if (storagePercent >= 80) return 'bg-amber-500';
    return 'bg-green-500';
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Storage Settings</h1>
        <p className="text-slate-400 mt-1">Manage video clip storage and retention</p>
      </div>

      {/* Storage Overview */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={cn(
              'w-12 h-12 rounded-xl flex items-center justify-center',
              storagePercent >= 90 ? 'bg-red-500/20 text-red-400' :
              storagePercent >= 80 ? 'bg-amber-500/20 text-amber-400' :
              'bg-green-500/20 text-green-400'
            )}>
              <HardDrive className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Storage Usage</h2>
              <p className="text-sm text-slate-400">
                {storageUsedGb.toFixed(1)} GB of {settings.maxStorageGb} GB used
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className={cn(
              'text-2xl font-bold',
              storagePercent >= 90 ? 'text-red-400' :
              storagePercent >= 80 ? 'text-amber-400' :
              'text-green-400'
            )}>
              {storagePercent.toFixed(0)}%
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="h-3 bg-slate-700 rounded-full overflow-hidden">
          <div 
            className={cn(
              'h-full rounded-full transition-all duration-500',
              getStorageColor()
            )}
            style={{ width: `${Math.min(storagePercent, 100)}%` }}
          />
        </div>

        {/* Warnings */}
        {storagePercent >= 90 && (
          <div className="mt-4 p-4 rounded-lg bg-red-500/10 border border-red-500/30 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5" />
            <div>
              <p className="text-sm text-red-400 font-medium">Storage almost full</p>
              <p className="text-xs text-red-400/70 mt-1">
                Consider deleting old clips or increasing retention settings to avoid losing new recordings.
              </p>
            </div>
          </div>
        )}

        {storagePercent >= 80 && storagePercent < 90 && (
          <div className="mt-4 p-4 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5" />
            <div>
              <p className="text-sm text-amber-400 font-medium">Storage running low</p>
              <p className="text-xs text-amber-400/70 mt-1">
                Consider cleaning up old recordings to free up space.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Storage Path */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <FolderOpen className="w-5 h-5 text-slate-400" />
          <div>
            <h2 className="text-lg font-semibold text-white">Storage Location</h2>
            <p className="text-sm text-slate-400">Where video clips are stored on your server</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="text"
            value={settings.storagePath}
            onChange={(e) => updateSetting('storagePath', e.target.value)}
            className="flex-1 px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors">
            Browse
          </button>
        </div>
      </div>

      {/* Retention Settings */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <Clock className="w-5 h-5 text-slate-400" />
          <div>
            <h2 className="text-lg font-semibold text-white">Retention Settings</h2>
            <p className="text-sm text-slate-400">How long video clips are kept</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">
              Retention Period
            </label>
            <select
              value={settings.retentionDays}
              onChange={(e) => updateSetting('retentionDays', parseInt(e.target.value))}
              className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value={7}>7 days</option>
              <option value={14}>14 days</option>
              <option value={30}>30 days</option>
              <option value={60}>60 days</option>
              <option value={90}>90 days</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/50 border border-slate-700">
            <div>
              <p className="font-medium text-white">Auto Cleanup</p>
              <p className="text-xs text-slate-500">
                Automatically delete clips older than retention period
              </p>
            </div>
            <button
              onClick={() => updateSetting('autoCleanup', !settings.autoCleanup)}
              className={cn(
                'relative w-12 h-6 rounded-full transition-colors',
                settings.autoCleanup ? 'bg-blue-500' : 'bg-slate-600'
              )}
            >
              <span className={cn(
                'absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform',
                settings.autoCleanup ? 'left-6' : 'left-0.5'
              )} />
            </button>
          </div>
        </div>

        <div className="mt-4 p-4 rounded-lg bg-slate-900/50">
          <p className="text-sm text-slate-400">
            <strong className="text-white">Estimated clips:</strong>{' '}
            {Math.round(settings.maxStorageGb / 0.5)} clips at ~500MB each
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Actual size varies based on recording quality and duration
          </p>
        </div>
      </div>

      {/* Storage Limit */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Storage Limit</h2>

        <div>
          <label className="block text-sm font-medium text-slate-400 mb-2">
            Maximum Storage (GB)
          </label>
          <input
            type="number"
            min={1}
            max={1000}
            value={settings.maxStorageGb}
            onChange={(e) => updateSetting('maxStorageGb', parseInt(e.target.value))}
            className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Cleanup */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Manual Cleanup</h2>
        <p className="text-sm text-slate-400 mb-4">
          Manually delete old video clips to free up storage space
        </p>

        <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/50 border border-slate-700">
          <div>
            <p className="font-medium text-white">Delete All Clips</p>
            <p className="text-xs text-slate-500">
              Permanently remove all stored video clips
            </p>
          </div>
          <button
            onClick={handleCleanup}
            disabled={cleaning}
            className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
          >
            {cleaning ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Trash2 className="w-4 h-4" />
            )}
            {cleaning ? 'Cleaning...' : 'Clean Up'}
          </button>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3">
        {saved && (
          <span className="text-sm text-green-400 flex items-center gap-1">
            <Check className="w-4 h-4" />
            Saved
          </span>
        )}
        <button
          onClick={handleSave}
          disabled={loading}
          className="flex items-center gap-2 px-6 py-2 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-medium rounded-lg transition-colors"
        >
          {loading && <Loader2 className="w-4 h-4 animate-spin" />}
          Save Changes
        </button>
      </div>
    </div>
  );
}
