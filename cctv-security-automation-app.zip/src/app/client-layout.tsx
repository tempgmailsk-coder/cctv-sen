'use client';

import { useApp } from '@/lib/store';
import AppLayout from '@/components/AppLayout';
import LoginForm from '@/components/LoginForm';

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const { state } = useApp();

  if (!state.isAuthenticated) {
    return <LoginForm />;
  }

  return <AppLayout>{children}</AppLayout>;
}
