'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useApp } from '@/lib/store';
import { 
  History, 
  Filter, 
  Trash2, 
  Download, 
  Eye,
  Video,
  User,
  AlertTriangle,
  ChevronDown,
  Check,
  X
} from 'lucide-react';
import { cn, formatRelativeTime, formatDateTime, getEventTypeColor, getEventTypeLabel } from '@/lib/utils';

export default function EventsPage() {
  const { state, dispatch } = useApp();
  const [filterType, setFilterType] = useState<string>('all');
  const [filterCamera, setFilterCamera] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedEvents, setSelectedEvents] = useState<Set<string>>(new Set());

  const filteredEvents = state.events.filter(event => {
    if (filterType !== 'all' && event.type !== filterType) return false;
    if (filterCamera !== 'all' && event.cameraId !== filterCamera) return false;
    return true;
  });

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedEvents);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedEvents(newSelected);
  };

  const selectAll = () => {
    if (selectedEvents.size === filteredEvents.length) {
      setSelectedEvents(new Set());
    } else {
      setSelectedEvents(new Set(filteredEvents.map(e => e.id)));
    }
  };

  const deleteSelected = () => {
    selectedEvents.forEach(id => {
      dispatch({ type: 'DELETE_EVENT', payload: id });
    });
    setSelectedEvents(new Set());
  };

  const markAllRead = () => {
    selectedEvents.forEach(id => {
      const event = state.events.find(e => e.id === id);
      if (event) {
        dispatch({ type: 'UPDATE_EVENT', payload: { ...event, isRead: true } });
      }
    });
    setSelectedEvents(new Set());
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Event History</h1>
          <p className="text-slate-400 mt-1">
            {filteredEvents.length} events • {state.dashboardStats.unreadEvents} unread
          </p>
        </div>
        <div className="flex items-center gap-3">
          {selectedEvents.size > 0 && (
            <div className="flex items-center gap-2">
              <button
                onClick={markAllRead}
                className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors text-sm"
              >
                <Check className="w-4 h-4" />
                Mark Read
              </button>
              <button
                onClick={deleteSelected}
                className="flex items-center gap-2 px-3 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors text-sm"
              >
                <Trash2 className="w-4 h-4" />
                Delete ({selectedEvents.size})
              </button>
            </div>
          )}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={cn(
              'flex items-center gap-2 px-4 py-2 rounded-lg transition-colors',
              showFilters ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            )}
          >
            <Filter className="w-5 h-5" />
            Filters
          </button>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-4 mb-6">
          <div className="grid sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Event Type</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Events</option>
                <option value="motion">Motion</option>
                <option value="person">Person</option>
                <option value="unknown_face">Unknown Person</option>
                <option value="known_face">Recognized</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Camera</label>
              <select
                value={filterCamera}
                onChange={(e) => setFilterCamera(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900/50 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Cameras</option>
                {state.cameras.map(camera => (
                  <option key={camera.id} value={camera.id}>{camera.name}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => {
                  setFilterType('all');
                  setFilterCamera('all');
                }}
                className="px-4 py-2 text-slate-400 hover:text-white transition-colors text-sm"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Events List */}
      {filteredEvents.length === 0 ? (
        <EmptyEventsState />
      ) : (
        <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 overflow-hidden">
          {/* Header */}
          <div className="px-4 py-3 border-b border-slate-700/50 flex items-center gap-3">
            <input
              type="checkbox"
              checked={selectedEvents.size === filteredEvents.length && filteredEvents.length > 0}
              onChange={selectAll}
              className="w-4 h-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"
            />
            <span className="text-sm text-slate-400">
              {selectedEvents.size > 0 ? `${selectedEvents.size} selected` : 'Select all'}
            </span>
          </div>

          {/* Events */}
          <div className="divide-y divide-slate-700/50">
            {filteredEvents.map((event) => (
              <EventRow 
                key={event.id} 
                event={event}
                isSelected={selectedEvents.has(event.id)}
                onToggle={() => toggleSelect(event.id)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function EventRow({ 
  event, 
  isSelected, 
  onToggle 
}: { 
  event: {
    id: string;
    cameraId: string;
    cameraName: string;
    type: 'motion' | 'person' | 'unknown_face' | 'known_face';
    confidence: number;
    thumbnailPath?: string;
    videoPath?: string;
    videoDuration?: number;
    metadata: Record<string, unknown>;
    isRead: boolean;
    personId?: string;
    personName?: string;
    createdAt: string;
  };
  isSelected: boolean;
  onToggle: () => void;
}) {
  const TypeIcon = {
    motion: Video,
    person: User,
    unknown_face: AlertTriangle,
    known_face: User,
  }[event.type];

  return (
    <div className={cn(
      'px-4 py-3 flex items-center gap-4 hover:bg-slate-700/30 transition-colors',
      !event.isRead && 'bg-blue-500/5'
    )}>
      <input
        type="checkbox"
        checked={isSelected}
        onChange={onToggle}
        className="w-4 h-4 rounded border-slate-600 bg-slate-700 text-blue-500 focus:ring-blue-500"
      />

      {/* Thumbnail */}
      <Link href={`/events/${event.id}`} className="relative flex-shrink-0">
        <div className="w-24 h-16 rounded-lg bg-slate-700 overflow-hidden">
          {event.thumbnailPath ? (
            <div className="w-full h-full bg-gradient-to-br from-blue-600/30 to-cyan-600/30" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <TypeIcon className="w-6 h-6 text-slate-500" />
            </div>
          )}
        </div>
        {event.videoPath && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity">
            <Eye className="w-6 h-6 text-white" />
          </div>
        )}
        {!event.isRead && (
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full border-2 border-slate-800" />
        )}
      </Link>

      {/* Info */}
      <Link href={`/events/${event.id}`} className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-white truncate">{event.cameraName}</p>
          <span className={cn(
            'px-2 py-0.5 rounded text-xs font-medium',
            getEventTypeColor(event.type)
          )}>
            {getEventTypeLabel(event.type)}
          </span>
        </div>
        <div className="flex items-center gap-3 mt-1">
          {event.personName && (
            <span className="text-sm text-green-400">{event.personName}</span>
          )}
          <span className="text-sm text-slate-500">
            {formatRelativeTime(event.createdAt)}
          </span>
          {event.videoDuration && (
            <span className="text-xs text-slate-600">
              {event.videoDuration}s
            </span>
          )}
        </div>
      </Link>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button 
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          title="Download"
        >
          <Download className="w-4 h-4" />
        </button>
        <button 
          className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
          title="Delete"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function EmptyEventsState() {
  return (
    <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-12 text-center">
      <div className="w-16 h-16 rounded-2xl bg-slate-700/50 flex items-center justify-center mx-auto mb-4">
        <History className="w-8 h-8 text-slate-500" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">No events found</h3>
      <p className="text-slate-400 max-w-md mx-auto">
        Events will appear here when motion or persons are detected by your cameras. 
        Try adjusting your filters or detection settings.
      </p>
    </div>
  );
}
