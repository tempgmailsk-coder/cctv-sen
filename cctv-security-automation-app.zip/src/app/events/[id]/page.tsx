'use client';

import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useApp } from '@/lib/store';
import { 
  ArrowLeft,
  Play,
  Download,
  Trash2,
  Share2,
  Calendar,
  Clock,
  Video,
  User,
  Eye,
  AlertTriangle,
  Check
} from 'lucide-react';
import { cn, formatDateTime, formatDuration, getEventTypeColor, getEventTypeLabel } from '@/lib/utils';

export default function EventDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { state, dispatch } = useApp();
  
  const event = state.events.find(e => e.id === params.id);
  const camera = event ? state.cameras.find(c => c.id === event.cameraId) : null;

  if (!event) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="w-12 h-12 text-slate-500 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">Event Not Found</h2>
        <p className="text-slate-400 mb-6">This event may have been deleted</p>
        <Link
          href="/events"
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Events
        </Link>
      </div>
    );
  }

  const handleMarkRead = () => {
    dispatch({ type: 'UPDATE_EVENT', payload: { ...event, isRead: true } });
  };

  const handleDelete = () => {
    dispatch({ type: 'DELETE_EVENT', payload: event.id });
    router.push('/events');
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link
            href="/events"
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-white">{event.cameraName}</h1>
              <span className={cn(
                'px-2 py-0.5 rounded text-xs font-medium',
                getEventTypeColor(event.type)
              )}>
                {getEventTypeLabel(event.type)}
              </span>
              {!event.isRead && (
                <span className="px-2 py-0.5 rounded text-xs font-medium bg-blue-500/20 text-blue-400">
                  New
                </span>
              )}
            </div>
            <p className="text-slate-400 mt-1">{formatDateTime(event.createdAt)}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {!event.isRead && (
            <button
              onClick={handleMarkRead}
              className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors text-sm"
            >
              <Check className="w-4 h-4" />
              Mark Read
            </button>
          )}
          <button className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
            <Share2 className="w-5 h-5" />
          </button>
          <button className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
            <Download className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDelete}
            className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Video Player */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 overflow-hidden mb-6">
        <div className="aspect-video relative bg-slate-900 flex items-center justify-center">
          {event.videoPath ? (
            <>
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-cyan-600/10" />
              <button className="relative z-10 w-20 h-20 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-sm flex items-center justify-center transition-colors">
                <Play className="w-10 h-10 text-white ml-1" />
              </button>
              {/* Timeline */}
              <div className="absolute bottom-0 inset-x-0 p-4">
                <div className="h-1 bg-slate-700 rounded-full mb-2">
                  <div className="h-full w-1/3 bg-blue-500 rounded-full" />
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>0:00</span>
                  <span>{event.videoDuration ? formatDuration(event.videoDuration) : '0:00'}</span>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center">
              <Video className="w-16 h-16 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-500">Video clip not available</p>
            </div>
          )}
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid sm:grid-cols-2 gap-6">
        {/* Event Details */}
        <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Event Details</h2>
          <div className="space-y-4">
            <DetailItem 
              icon={Video}
              label="Camera"
              value={event.cameraName}
            />
            <DetailItem 
              icon={AlertTriangle}
              label="Detection Type"
              value={getEventTypeLabel(event.type)}
            />
            <DetailItem 
              icon={Eye}
              label="Confidence"
              value={`${(event.confidence * 100).toFixed(0)}%`}
            />
            <DetailItem 
              icon={Clock}
              label="Duration"
              value={event.videoDuration ? `${event.videoDuration} seconds` : 'N/A'}
            />
            <DetailItem 
              icon={Calendar}
              label="Recorded"
              value={formatDateTime(event.createdAt)}
            />
          </div>
        </div>

        {/* Person Info (if applicable) */}
        <div className="bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            {event.personName ? 'Recognized Person' : 'Detection Info'}
          </h2>
          {event.personName ? (
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-slate-700 mx-auto mb-4 flex items-center justify-center">
                <User className="w-10 h-10 text-slate-500" />
              </div>
              <p className="text-xl font-semibold text-white">{event.personName}</p>
              <p className="text-sm text-green-400 mt-1">Known Individual</p>
              <Link
                href="/persons"
                className="inline-block mt-4 text-sm text-blue-400 hover:text-blue-300"
              >
                View all known persons →
              </Link>
            </div>
          ) : event.type === 'unknown_face' ? (
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-red-500/20 mx-auto mb-4 flex items-center justify-center">
                <AlertTriangle className="w-10 h-10 text-red-400" />
              </div>
              <p className="text-xl font-semibold text-white">Unknown Person</p>
              <p className="text-sm text-slate-400 mt-1">
                Face did not match any registered persons
              </p>
              <p className="text-xs text-slate-500 mt-2">
                Confidence threshold: {(event.confidence * 100).toFixed(0)}%
              </p>
            </div>
          ) : (
            <div className="text-center py-6">
              <Eye className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400">No person identified</p>
              <p className="text-xs text-slate-500 mt-1">
                This event was triggered by {event.type === 'motion' ? 'motion' : 'movement'} detection
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Camera Info */}
      {camera && (
        <div className="mt-6 bg-slate-800/50 rounded-xl border border-slate-700/50 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">Camera Information</h2>
          <div className="grid sm:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-slate-400">IP Address</p>
              <p className="font-medium text-white">{camera.ip}:{camera.port}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Protocol</p>
              <p className="font-medium text-white uppercase">{camera.protocol}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Channel</p>
              <p className="font-medium text-white">{camera.channel}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Status</p>
              <p className={cn(
                'font-medium',
                camera.status === 'online' ? 'text-green-400' : 'text-slate-400'
              )}>
                {camera.status.charAt(0).toUpperCase() + camera.status.slice(1)}
              </p>
            </div>
          </div>
          <Link
            href={`/cameras/${camera.id}/settings`}
            className="inline-flex items-center gap-2 mt-4 text-sm text-blue-400 hover:text-blue-300"
          >
            View camera settings →
          </Link>
        </div>
      )}
    </div>
  );
}

function DetailItem({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="w-5 h-5 text-slate-500" />
      <div>
        <p className="text-sm text-slate-400">{label}</p>
        <p className="font-medium text-white">{value}</p>
      </div>
    </div>
  );
}
