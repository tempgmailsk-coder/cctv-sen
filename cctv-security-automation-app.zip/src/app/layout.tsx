import type { Metadata } from "next";
import "./globals.css";
import { AppProvider } from "@/lib/store";
import ClientLayout from "./client-layout";

export const metadata: Metadata = {
  title: "SecureWatch - CCTV Security Automation",
  description: "Professional CCTV security automation with AI-powered person detection and instant notifications",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-900 text-slate-100 antialiased">
        <AppProvider>
          <ClientLayout>{children}</ClientLayout>
        </AppProvider>
      </body>
    </html>
  );
}
