'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/lib/store';
import { 
  ArrowLeft,
  ArrowRight,
  Check,
  Video,
  Wifi,
  Shield,
  Eye,
  Loader2,
  TestTube
} from 'lucide-react';
import { cn } from '@/lib/utils';

const STEPS = [
  { id: 1, name: 'Connection', icon: Wifi, description: 'Configure camera connection' },
  { id: 2, name: 'Authentication', icon: Shield, description: 'Enter credentials' },
  { id: 3, name: 'Detection', icon: Eye, description: 'Configure detection settings' },
  { id: 4, name: 'Review', icon: Check, description: 'Confirm and save' },
];

export default function CameraSetupPage() {
  const router = useRouter();
  const { dispatch } = useApp();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [connectionTested, setConnectionTested] = useState(false);
  const [connectionSuccess, setConnectionSuccess] = useState(false);

  const [formData, setFormData] = useState({
    // Step 1: Connection
    protocol: 'rtsp',
    ip: '',
    port: 554,
    channel: 1,
    // Step 2: Auth
    username: '',
    password: '',
    // Step 3: Detection
    name: '',
    location: '',
    motionEnabled: true,
    personEnabled: true,
    faceEnabled: false,
    sensitivity: 5,
    // Step 4: Review
  });

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const testConnection = async () => {
    setLoading(true);
    // Simulate connection test
    await new Promise(resolve => setTimeout(resolve, 1500));
    setConnectionTested(true);
    setConnectionSuccess(true);
    setLoading(false);
  };

  const handleSubmit = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Add camera to state
    dispatch({
      type: 'ADD_CAMERA',
      payload: {
        id: 'cam-' + Date.now(),
        name: formData.name || `Camera ${formData.channel}`,
        ip: formData.ip,
        port: formData.port,
        protocol: formData.protocol as 'rtsp' | 'onvif' | 'cgi' | 'http',
        channel: formData.channel,
        location: formData.location,
        status: 'online',
        motionEnabled: formData.motionEnabled,
        personEnabled: formData.personEnabled,
        faceEnabled: formData.faceEnabled,
        sensitivity: formData.sensitivity,
        createdAt: new Date().toISOString(),
      },
    });

    setLoading(false);
    router.push('/cameras');
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => router.back()}
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-white">Add New Camera</h1>
          <p className="text-slate-400 mt-1">Configure your CP PLUS camera step by step</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {STEPS.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div className="flex flex-col items-center">
                <div className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center transition-all',
                  currentStep > step.id ? 'bg-green-500 text-white' :
                  currentStep === step.id ? 'bg-blue-500 text-white' :
                  'bg-slate-700 text-slate-400'
                )}>
                  {currentStep > step.id ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <step.icon className="w-5 h-5" />
                  )}
                </div>
                <span className={cn(
                  'text-xs mt-2 hidden sm:block',
                  currentStep >= step.id ? 'text-white' : 'text-slate-500'
                )}>
                  {step.name}
                </span>
              </div>
              {index < STEPS.length - 1 && (
                <div className={cn(
                  'w-12 sm:w-24 h-0.5 mx-2',
                  currentStep > step.id ? 'bg-green-500' : 'bg-slate-700'
                )} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Form Steps */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6">
        {/* Step 1: Connection */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-2">Camera Connection</h2>
              <p className="text-sm text-slate-400">Enter your camera&apos;s network details</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Protocol
              </label>
              <div className="grid grid-cols-3 gap-3">
                {['rtsp', 'onvif', 'cgi'].map((proto) => (
                  <button
                    key={proto}
                    onClick={() => setFormData({ ...formData, protocol: proto })}
                    className={cn(
                      'p-3 rounded-lg border text-center transition-all',
                      formData.protocol === proto
                        ? 'border-blue-500 bg-blue-500/20 text-blue-400'
                        : 'border-slate-600 text-slate-400 hover:border-slate-500'
                    )}
                  >
                    <span className="font-medium uppercase">{proto}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  IP Address
                </label>
                <input
                  type="text"
                  value={formData.ip}
                  onChange={(e) => setFormData({ ...formData, ip: e.target.value })}
                  placeholder="192.168.1.100"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Port
                </label>
                <input
                  type="number"
                  value={formData.port}
                  onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) })}
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Channel Number
              </label>
              <input
                type="number"
                min={1}
                max={32}
                value={formData.channel}
                onChange={(e) => setFormData({ ...formData, channel: parseInt(e.target.value) })}
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-slate-500 mt-1">For DVR/NVR systems, enter the channel number (1-32)</p>
            </div>
          </div>
        )}

        {/* Step 2: Authentication */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-2">Camera Credentials</h2>
              <p className="text-sm text-slate-400">Enter the login credentials for your camera</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Username
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="admin"
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Password
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-slate-500 mt-1">
                Your credentials are encrypted and stored securely
              </p>
            </div>

            <button
              onClick={testConnection}
              disabled={loading || !formData.ip || !formData.username}
              className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 disabled:bg-slate-700/50 disabled:text-slate-500 text-white rounded-lg transition-colors"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <TestTube className="w-4 h-4" />
              )}
              Test Connection
            </button>

            {connectionTested && (
              <div className={cn(
                'p-4 rounded-lg',
                connectionSuccess 
                  ? 'bg-green-500/20 border border-green-500/30 text-green-400'
                  : 'bg-red-500/20 border border-red-500/30 text-red-400'
              )}>
                {connectionSuccess 
                  ? '✓ Connection successful! Camera is reachable.'
                  : '✗ Connection failed. Please check your settings.'}
              </div>
            )}
          </div>
        )}

        {/* Step 3: Detection Settings */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-2">Detection Settings</h2>
              <p className="text-sm text-slate-400">Configure how this camera detects events</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Camera Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Front Gate"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Location
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="Entrance"
                  className="w-full px-4 py-3 bg-slate-900/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Detection Types
              </label>
              <div className="space-y-3">
                <ToggleOption
                  label="Motion Detection"
                  description="Detect any movement in the camera view"
                  checked={formData.motionEnabled}
                  onChange={(v) => setFormData({ ...formData, motionEnabled: v })}
                />
                <ToggleOption
                  label="Person Detection"
                  description="Filter to only detect human figures"
                  checked={formData.personEnabled}
                  onChange={(v) => setFormData({ ...formData, personEnabled: v })}
                />
                <ToggleOption
                  label="Face Recognition"
                  description="Identify known individuals (requires AI model)"
                  checked={formData.faceEnabled}
                  onChange={(v) => setFormData({ ...formData, faceEnabled: v })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-3">
                Sensitivity: {formData.sensitivity}/10
              </label>
              <input
                type="range"
                min={1}
                max={10}
                value={formData.sensitivity}
                onChange={(e) => setFormData({ ...formData, sensitivity: parseInt(e.target.value) })}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-1">
                <span>Low</span>
                <span>High</span>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Review */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-white mb-2">Review & Confirm</h2>
              <p className="text-sm text-slate-400">Please verify your camera settings</p>
            </div>

            <div className="bg-slate-900/50 rounded-xl p-4 space-y-4">
              <ReviewItem label="Name" value={formData.name || `Camera ${formData.channel}`} />
              <ReviewItem label="IP Address" value={`${formData.ip}:${formData.port}`} />
              <ReviewItem label="Protocol" value={formData.protocol.toUpperCase()} />
              <ReviewItem label="Channel" value={`Channel ${formData.channel}`} />
              <ReviewItem label="Location" value={formData.location || 'Not specified'} />
              <ReviewItem label="Detection" value={[
                formData.motionEnabled && 'Motion',
                formData.personEnabled && 'Person',
                formData.faceEnabled && 'Face'
              ].filter(Boolean).join(', ') || 'None'} />
              <ReviewItem label="Sensitivity" value={`${formData.sensitivity}/10`} />
            </div>

            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/30">
              <p className="text-sm text-blue-400">
                <strong>Note:</strong> Your camera credentials are encrypted using AES-256-GCM and stored securely. They will never be exposed in logs or notifications.
              </p>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-700">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className="flex items-center gap-2 px-4 py-2 text-slate-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

          {currentStep < 4 ? (
            <button
              onClick={handleNext}
              disabled={currentStep === 2 && !connectionTested}
              className="flex items-center gap-2 px-6 py-2 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-500/50 text-white font-medium rounded-lg transition-colors"
            >
              Next
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="flex items-center gap-2 px-6 py-2 bg-green-500 hover:bg-green-600 disabled:bg-green-500/50 text-white font-medium rounded-lg transition-colors"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              Add Camera
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function ToggleOption({ 
  label, 
  description, 
  checked, 
  onChange 
}: { 
  label: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/50">
      <div>
        <p className="font-medium text-white">{label}</p>
        <p className="text-xs text-slate-500">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={cn(
          'relative w-12 h-6 rounded-full transition-colors',
          checked ? 'bg-blue-500' : 'bg-slate-600'
        )}
      >
        <span className={cn(
          'absolute top-1 w-4 h-4 rounded-full bg-white transition-transform',
          checked ? 'left-7' : 'left-1'
        )} />
      </button>
    </div>
  );
}

function ReviewItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-slate-400">{label}</span>
      <span className="text-sm font-medium text-white">{value}</span>
    </div>
  );
}
