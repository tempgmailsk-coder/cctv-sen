'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useApp } from '@/lib/store';
import { 
  Video, 
  Plus, 
  Settings, 
  Eye, 
  Power,
  RefreshCw,
  ExternalLink,
  Wifi,
  WifiOff,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function CamerasPage() {
  const { state, refreshCameras } = useApp();
  const [loading, setLoading] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);

  const handleRefresh = async () => {
    setLoading(true);
    await refreshCameras();
    setLoading(false);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Live Cameras</h1>
          <p className="text-slate-400 mt-1">
            {state.cameras.filter(c => c.status === 'online').length} of {state.cameras.length} cameras online
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <RefreshCw className={cn('w-5 h-5', loading && 'animate-spin')} />
          </button>
          <Link
            href="/cameras/setup"
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Camera
          </Link>
        </div>
      </div>

      {/* Camera Grid */}
      {state.cameras.length === 0 ? (
        <EmptyCamerasState />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {state.cameras.map((camera) => (
            <CameraCard 
              key={camera.id} 
              camera={camera}
              isSelected={selectedCamera === camera.id}
              onSelect={() => setSelectedCamera(selectedCamera === camera.id ? null : camera.id)}
            />
          ))}
        </div>
      )}

      {/* Camera Detail Modal */}
      {selectedCamera && (
        <CameraDetailModal 
          camera={state.cameras.find(c => c.id === selectedCamera)!}
          onClose={() => setSelectedCamera(null)}
        />
      )}
    </div>
  );
}

function CameraCard({ 
  camera, 
  isSelected, 
  onSelect 
}: { 
  camera: {
    id: string;
    name: string;
    ip: string;
    port: number;
    channel: number;
    protocol: string;
    location?: string;
    status: 'online' | 'offline' | 'error';
    personEnabled: boolean;
    faceEnabled: boolean;
    motionEnabled: boolean;
  };
  isSelected: boolean;
  onSelect: () => void;
}) {
  const statusConfig = {
    online: { icon: Wifi, color: 'text-green-500', bg: 'bg-green-500', label: 'Online' },
    offline: { icon: WifiOff, color: 'text-slate-500', bg: 'bg-slate-500', label: 'Offline' },
    error: { icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-500', label: 'Error' },
  };

  const status = statusConfig[camera.status];

  return (
    <div 
      className={cn(
        'bg-slate-800/50 rounded-2xl border overflow-hidden transition-all cursor-pointer',
        isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-slate-700/50 hover:border-slate-600'
      )}
      onClick={onSelect}
    >
      {/* Video Preview */}
      <div className="aspect-video relative bg-slate-900">
        {camera.status === 'online' ? (
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-cyan-600/20 flex items-center justify-center">
            <div className="text-center">
              <Video className="w-12 h-12 text-white/50 mx-auto mb-2" />
              <p className="text-white/50 text-sm">Live Stream</p>
            </div>
          </div>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <status.icon className={cn('w-12 h-12', status.color)} />
          </div>
        )}

        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          <span className={cn(
            'inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium backdrop-blur-sm',
            camera.status === 'online' ? 'bg-green-500/80 text-white' :
            camera.status === 'error' ? 'bg-red-500/80 text-white' :
            'bg-slate-700/80 text-slate-300'
          )}>
            <span className={cn('w-2 h-2 rounded-full', status.bg)} />
            {status.label}
          </span>
        </div>

        {/* Quick Actions */}
        <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
          <button className="p-3 rounded-full bg-blue-500 hover:bg-blue-600 text-white transition-colors">
            <Eye className="w-5 h-5" />
          </button>
          <Link 
            href={`/cameras/${camera.id}`}
            className="p-3 rounded-full bg-slate-700 hover:bg-slate-600 text-white transition-colors"
            onClick={(e) => e.stopPropagation()}
          >
            <ExternalLink className="w-5 h-5" />
          </Link>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-white truncate">{camera.name}</h3>
            <p className="text-sm text-slate-500 mt-0.5">{camera.location || camera.ip}</p>
          </div>
          <Link 
            href={`/cameras/${camera.id}/settings`}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
            onClick={(e) => e.stopPropagation()}
          >
            <Settings className="w-4 h-4" />
          </Link>
        </div>

        {/* Detection badges */}
        <div className="flex items-center gap-2 mt-3">
          {camera.personEnabled && (
            <span className="px-2 py-0.5 rounded text-xs font-medium bg-blue-500/20 text-blue-400">
              Person
            </span>
          )}
          {camera.faceEnabled && (
            <span className="px-2 py-0.5 rounded text-xs font-medium bg-purple-500/20 text-purple-400">
              Face
            </span>
          )}
          {camera.motionEnabled && (
            <span className="px-2 py-0.5 rounded text-xs font-medium bg-amber-500/20 text-amber-400">
              Motion
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

function CameraDetailModal({ 
  camera, 
  onClose 
}: { 
  camera: {
    id: string;
    name: string;
    ip: string;
    port: number;
    channel: number;
    protocol: string;
  };
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-slate-900 rounded-2xl overflow-hidden max-w-4xl w-full border border-slate-700"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">{camera.name}</h2>
            <p className="text-sm text-slate-400">{camera.ip}:{camera.port}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            ✕
          </button>
        </div>

        {/* Video */}
        <div className="aspect-video bg-slate-800 flex items-center justify-center">
          <div className="text-center">
            <Video className="w-16 h-16 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-500">Live stream preview</p>
            <p className="text-xs text-slate-600 mt-1">Channel {camera.channel} • {camera.protocol.toUpperCase()}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="p-4 flex items-center justify-center gap-3 border-t border-slate-800">
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors">
            <Eye className="w-4 h-4" />
            Full Screen
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
          <Link 
            href={`/cameras/${camera.id}/settings`}
            className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            <Settings className="w-4 h-4" />
            Settings
          </Link>
        </div>
      </div>
    </div>
  );
}

function EmptyCamerasState() {
  return (
    <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-12 text-center">
      <div className="w-16 h-16 rounded-2xl bg-slate-700/50 flex items-center justify-center mx-auto mb-4">
        <Video className="w-8 h-8 text-slate-500" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">No cameras configured</h3>
      <p className="text-slate-400 mb-6 max-w-md mx-auto">
        Add your first CP PLUS camera to start monitoring your property with real-time detection and alerts.
      </p>
      <Link
        href="/cameras/setup"
        className="inline-flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors"
      >
        <Plus className="w-5 h-5" />
        Add Your First Camera
      </Link>
    </div>
  );
}
