'use client';

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { 
  Users, 
  Plus, 
  Settings,
  User,
  Trash2,
  Video,
  Clock,
  Eye
} from 'lucide-react';
import { cn, formatRelativeTime } from '@/lib/utils';
import Link from 'next/link';

export default function KnownPersonsPage() {
  const { state, dispatch } = useApp();
  const [selectedPerson, setSelectedPerson] = useState<string | null>(null);

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Known Persons</h1>
          <p className="text-slate-400 mt-1">
            {state.knownPersons.length} registered individuals for face recognition
          </p>
        </div>
        <button
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Person
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-500/10 rounded-xl border border-blue-500/30 p-4 mb-6">
        <div className="flex items-start gap-3">
          <Users className="w-5 h-5 text-blue-400 mt-0.5" />
          <div>
            <p className="text-sm text-blue-400 font-medium">Face Recognition</p>
            <p className="text-sm text-slate-400 mt-1">
              Known persons are compared against detected faces using AI. 
              When confidence exceeds your threshold, the person is identified.
              Unknown persons trigger alerts even if face recognition is disabled.
            </p>
          </div>
        </div>
      </div>

      {/* Persons Grid */}
      {state.knownPersons.length === 0 ? (
        <EmptyPersonsState />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {state.knownPersons.map((person) => (
            <PersonCard 
              key={person.id} 
              person={person}
              isSelected={selectedPerson === person.id}
              onSelect={() => setSelectedPerson(selectedPerson === person.id ? null : person.id)}
            />
          ))}
        </div>
      )}

      {/* Person Detail Panel */}
      {selectedPerson && (
        <PersonDetailPanel 
          person={state.knownPersons.find(p => p.id === selectedPerson)!}
          onClose={() => setSelectedPerson(null)}
          events={state.events}
        />
      )}
    </div>
  );
}

function PersonCard({ 
  person, 
  isSelected, 
  onSelect 
}: { 
  person: {
    id: string;
    name: string;
    faces: { url: string; embedding?: number[] }[];
    confidence: number;
    eventCount: number;
    lastSeen?: string;
    createdAt: string;
  };
  isSelected: boolean;
  onSelect: () => void;
}) {
  return (
    <div 
      className={cn(
        'bg-slate-800/50 rounded-2xl border overflow-hidden cursor-pointer transition-all',
        isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-slate-700/50 hover:border-slate-600'
      )}
      onClick={onSelect}
    >
      {/* Header with avatar */}
      <div className="p-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white text-2xl font-bold">
          {person.name.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-white truncate">{person.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className={cn(
              'px-2 py-0.5 rounded text-xs font-medium',
              person.confidence >= 0.9 ? 'bg-green-500/20 text-green-400' :
              person.confidence >= 0.8 ? 'bg-amber-500/20 text-amber-400' :
              'bg-slate-500/20 text-slate-400'
            )}>
              {(person.confidence * 100).toFixed(0)}% confidence
            </span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-6 pb-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-900/50 rounded-lg p-3">
            <div className="flex items-center gap-2 text-slate-400 mb-1">
              <Video className="w-4 h-4" />
              <span className="text-xs">Events</span>
            </div>
            <p className="text-xl font-bold text-white">{person.eventCount}</p>
          </div>
          <div className="bg-slate-900/50 rounded-lg p-3">
            <div className="flex items-center gap-2 text-slate-400 mb-1">
              <Clock className="w-4 h-4" />
              <span className="text-xs">Last Seen</span>
            </div>
            <p className="text-sm font-medium text-white">
              {person.lastSeen ? formatRelativeTime(person.lastSeen) : 'Never'}
            </p>
          </div>
        </div>
      </div>

      {/* Faces preview */}
      <div className="px-6 pb-4">
        <p className="text-xs text-slate-500 mb-2">{person.faces.length} registered faces</p>
        <div className="flex gap-2">
          {person.faces.slice(0, 3).map((face, i) => (
            <div 
              key={i}
              className="w-12 h-12 rounded-lg bg-slate-700 overflow-hidden"
            >
              {face.url ? (
                <div className="w-full h-full bg-gradient-to-br from-slate-600 to-slate-700" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <User className="w-6 h-6 text-slate-500" />
                </div>
              )}
            </div>
          ))}
          {person.faces.length > 3 && (
            <div className="w-12 h-12 rounded-lg bg-slate-700/50 flex items-center justify-center">
              <span className="text-xs text-slate-400">+{person.faces.length - 3}</span>
            </div>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="px-6 py-4 border-t border-slate-700/50 flex items-center justify-between">
        <Link
          href={`/persons/${person.id}`}
          className="text-sm text-blue-400 hover:text-blue-300 font-medium"
          onClick={(e) => e.stopPropagation()}
        >
          View Details
        </Link>
        <button className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function PersonDetailPanel({ 
  person, 
  onClose,
  events
}: { 
  person: {
    id: string;
    name: string;
    faces: { url: string; embedding?: number[] }[];
    confidence: number;
    eventCount: number;
    lastSeen?: string;
    createdAt: string;
  };
  onClose: () => void;
  events: {
    id: string;
    cameraName: string;
    personId?: string;
    createdAt: string;
  }[];
}) {
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div 
        className="bg-slate-900 rounded-2xl overflow-hidden max-w-lg w-full border border-slate-700"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white text-2xl font-bold">
              {person.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-white">{person.name}</h2>
              <p className="text-slate-400">Face Recognition Profile</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="p-6 grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{person.eventCount}</p>
            <p className="text-xs text-slate-400">Total Events</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{person.faces.length}</p>
            <p className="text-xs text-slate-400">Registered Faces</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{(person.confidence * 100).toFixed(0)}%</p>
            <p className="text-xs text-slate-400">Confidence</p>
          </div>
        </div>

        {/* Recent Events */}
        <div className="px-6 pb-6">
          <h3 className="text-sm font-medium text-slate-400 mb-3">Recent Detections</h3>
          <div className="space-y-2">
            {events
              .filter((e: { personId?: string }) => e.personId === person.id)
              .slice(0, 3)
              .map((event: { id: string; cameraName: string; createdAt: string }) => (
                <Link
                  key={event.id}
                  href={`/events/${event.id}`}
                  className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
                    <Eye className="w-5 h-5 text-slate-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white">{event.cameraName}</p>
                    <p className="text-xs text-slate-500">{formatRelativeTime(event.createdAt)}</p>
                  </div>
                </Link>
              ))}
            {events.filter((e: { personId?: string }) => e.personId === person.id).length === 0 && (
              <p className="text-sm text-slate-500 text-center py-4">No recent detections</p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            Close
          </button>
          <Link
            href={`/persons/${person.id}`}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            Edit Person
          </Link>
        </div>
      </div>
    </div>
  );
}

function EmptyPersonsState() {
  return (
    <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-12 text-center">
      <div className="w-16 h-16 rounded-2xl bg-slate-700/50 flex items-center justify-center mx-auto mb-4">
        <Users className="w-8 h-8 text-slate-500" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">No known persons yet</h3>
      <p className="text-slate-400 mb-6 max-w-md mx-auto">
        Add family members, friends, or frequent visitors to enable face recognition alerts.
        When they&apos;re detected, you&apos;ll know who it is.
      </p>
      <button
        className="inline-flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors"
      >
        <Plus className="w-5 h-5" />
        Add First Person
      </button>
    </div>
  );
}
