'use client';

import { useState } from 'react';
import { 
  Book,
  Video,
  Wifi,
  Shield,
  Bell,
  User,
  HardDrive,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

const helpSections = [
  {
    id: 'getting-started',
    title: 'Getting Started',
    icon: Book,
    content: `Welcome to SecureWatch! This guide will help you set up your CCTV security system.

**Step 1: Add Your Cameras**
Navigate to "Live Cameras" and click "Add Camera". Enter your CP PLUS camera's IP address, port, and credentials.

**Step 2: Configure Detection**
Choose which types of detection you want for each camera:
- Motion Detection: Detects any movement
- Person Detection: Filters to only human figures
- Face Recognition: Identifies known individuals

**Step 3: Set Up Notifications**
Go to Settings > Notifications to configure how and when you receive alerts.

**Step 4: Add Known Persons**
Register family members and frequent visitors for face recognition alerts.`,
  },
  {
    id: 'cp-plus-integration',
    title: 'CP PLUS Integration',
    icon: Video,
    content: `SecureWatch supports CP PLUS DVR/NVR systems through multiple protocols:

**Supported Protocols (in order of preference):**

1. **HTTP Event Stream (Recommended)**
   - CP PLUS provides HTTP push events for motion detection
   - Lowest latency, uses device's own detection
   - Configure in DVR: Network > Event > HTTP Push

2. **RTSP Stream**
   - Standard video streaming protocol
   - Format: rtsp://[ip]:[port]/Streaming/Channels/[ch]01
   - Supports main (01) and sub (02) streams

3. **ONVIF Protocol**
   - Standardized IP camera interface
   - Used for device discovery and stream URIs
   - Port: 80 or 8080 typically

4. **CGI Commands**
   - HTTP-based API for camera control
   - Login: /cgi-bin/login.cgi
   - Event: /cgi-bin/eventManager.cgi

**Common CP PLUS Ports:**
- RTSP: 554
- ONVIF: 80 or 8080
- HTTP: 80
- HTTPS: 443

**Default Credentials:**
Most CP PLUS devices use:
- Username: admin
- Password: admin123 or empty`,
  },
  {
    id: 'detection-settings',
    title: 'Detection Settings',
    icon: Shield,
    content: `Configure detection to minimize false alerts while catching important events.

**Sensitivity (1-10)**
- Lower values = fewer false positives
- Higher values = more sensitive
- Recommended: 5-7 for outdoor cameras, 3-5 for indoor

**Detection Zones**
Draw custom areas on the camera view to only monitor specific regions. This helps ignore irrelevant movement like trees or busy streets.

**Detection Types:**
- Motion: Catches all movement (animals, vehicles, shadows)
- Person: AI filters to only human figures
- Face: Requires person detection, then identifies faces

**Cooldown Period**
Set minimum time between alerts (0-5 minutes) to prevent notification spam.`,
  },
  {
    id: 'notifications',
    title: 'Notification Settings',
    icon: Bell,
    content: `Control how and when you receive security alerts.

**Push Notifications**
Enable/disable all notifications from the main toggle.

**Notification Types:**
- Motion Detection: General movement alerts
- Person Detection: Human figure alerts
- Unknown Person: Face not recognized alerts

**Camera Selection**
Choose which cameras can send notifications. Useful if some cameras are in high-traffic areas.

**Quiet Hours**
During specified hours, notifications are stored but not pushed. Unknown person alerts always go through immediately.

**Notification Content:**
Each notification includes:
- Camera name
- Detection type
- Thumbnail image
- Video clip (optional)
- Timestamp`,
  },
  {
    id: 'face-recognition',
    title: 'Face Recognition',
    icon: User,
    content: `SecureWatch uses AI to identify known individuals.

**How It Works:**
1. Face detected in camera view
2. Face embedding extracted (mathematical representation)
3. Compared against registered known persons
4. If match confidence > threshold: Identified person
5. If no match: "Unknown Person" alert

**Adding Known Persons:**
1. Go to "Known Persons"
2. Click "Add Person"
3. Enter name
4. Upload photos or capture from events
5. System automatically detects and registers faces

**Confidence Threshold:**
- High (90%+): Fewer false identifications, may miss similar faces
- Medium (80-90%): Balanced approach
- Low (70-80%): More identifications, may include false positives

**Tips for Best Results:**
- Use clear, well-lit photos
- Include multiple angles
- Avoid sunglasses or masks
- Update photos periodically`,
  },
  {
    id: 'storage',
    title: 'Storage Management',
    icon: HardDrive,
    content: `Manage video clip storage and retention.

**Video Clips:**
When an event is detected, a clip is saved including:
- 5 seconds before detection (pre-roll)
- Up to 30 seconds after detection (post-roll)

**Storage Location:**
By default, clips are stored in /storage on the server. Configure this in Settings > Storage.

**Retention:**
Set how long clips are kept (7-90 days). Older clips are automatically deleted.

**Auto Cleanup:**
When enabled, clips older than the retention period are automatically removed.

**Manual Cleanup:**
Use "Clean Up" to immediately delete all stored clips and free up space.

**Storage Estimates:**
- 1 hour of HD video ≈ 500MB - 1GB
- 100GB storage ≈ 100-200 event clips (depending on duration)`,
  },
  {
    id: 'troubleshooting',
    title: 'Troubleshooting',
    icon: AlertCircle,
    content: `Common issues and solutions:

**Camera Offline**
- Check network connection
- Verify IP address and port
- Check firewall settings
- Restart the camera/DVR
- Verify credentials

**No Motion Detection**
- Enable motion detection in camera settings
- Check detection zones are configured
- Lower sensitivity if too many false positives
- Verify camera timestamp is correct

**Notifications Not Working**
- Check notification settings are enabled
- Verify camera is selected for notifications
- Check quiet hours settings
- Ensure app has notification permissions

**Face Recognition Not Working**
- Enable face recognition in camera settings
- Ensure person detection is enabled
- Add more clear photos to known persons
- Check lighting conditions
- Adjust confidence threshold

**Storage Full**
- Increase storage limit or delete old clips
- Reduce retention period
- Disable auto cleanup temporarily`,
  },
];

const faqs = [
  {
    q: 'How do I find my camera IP address?',
    a: 'Check your DVR/NVR network settings, or use a network scanner app to find devices on your local network.',
  },
  {
    q: 'Can I use SecureWatch remotely?',
    a: 'Yes, but you need to set up port forwarding on your router or use a VPN to access your local network securely.',
  },
  {
    q: 'Does SecureWatch record 24/7?',
    a: 'No, SecureWatch only saves clips when events are detected. This saves storage and makes reviewing events easier.',
  },
  {
    q: 'How accurate is face recognition?',
    a: 'Accuracy depends on lighting, image quality, and angle. With good conditions, accuracy is typically 90%+ for registered persons.',
  },
  {
    q: 'Can I add multiple users?',
    a: 'This is planned for future versions. Currently, SecureWatch is designed for single-user personal use.',
  },
  {
    q: 'Is my data secure?',
    a: 'Yes. Camera credentials are encrypted, notifications don\'t expose passwords, and all data is stored locally by default.',
  },
];

export default function HelpPage() {
  const [expandedSection, setExpandedSection] = useState<string | null>('getting-started');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Help & Documentation</h1>
        <p className="text-slate-400">
          Learn how to set up and use SecureWatch for your CCTV security system
        </p>
      </div>

      {/* Quick Links */}
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <QuickLink
          icon={Video}
          label="Add First Camera"
          href="/cameras/setup"
        />
        <QuickLink
          icon={Bell}
          label="Configure Alerts"
          href="/settings/notifications"
        />
        <QuickLink
          icon={User}
          label="Register Faces"
          href="/persons"
        />
      </div>

      {/* Help Sections */}
      <div className="space-y-4 mb-12">
        {helpSections.map((section) => (
          <div
            key={section.id}
            className="bg-slate-800/50 rounded-2xl border border-slate-700/50 overflow-hidden"
          >
            <button
              onClick={() => setExpandedSection(expandedSection === section.id ? null : section.id)}
              className="w-full px-6 py-4 flex items-center gap-4 text-left hover:bg-slate-700/30 transition-colors"
            >
              <section.icon className="w-5 h-5 text-blue-400" />
              <span className="flex-1 font-semibold text-white">{section.title}</span>
              {expandedSection === section.id ? (
                <ChevronDown className="w-5 h-5 text-slate-400" />
              ) : (
                <ChevronRight className="w-5 h-5 text-slate-400" />
              )}
            </button>
            {expandedSection === section.id && (
              <div className="px-6 pb-6 border-t border-slate-700/50">
                <div className="pt-4 prose prose-invert prose-sm max-w-none">
                  <pre className="whitespace-pre-wrap text-slate-300 font-sans text-sm bg-transparent p-0 m-0">
                    {section.content}
                  </pre>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* FAQs */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-white mb-4">Frequently Asked Questions</h2>
        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-slate-800/50 rounded-xl border border-slate-700/50 overflow-hidden"
            >
              <button
                onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                className="w-full px-4 py-3 flex items-center gap-3 text-left hover:bg-slate-700/30 transition-colors"
              >
                {expandedFaq === index ? (
                  <ChevronDown className="w-4 h-4 text-blue-400 flex-shrink-0" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                )}
                <span className="font-medium text-white">{faq.q}</span>
              </button>
              {expandedFaq === index && (
                <div className="px-4 pb-4 pl-10 border-t border-slate-700/50">
                  <p className="text-slate-400 text-sm pt-3">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Support */}
      <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-2xl border border-blue-500/30 p-6">
        <h2 className="text-lg font-semibold text-white mb-2">Need More Help?</h2>
        <p className="text-slate-400 mb-4">
          If you can&apos;t find what you&apos;re looking for, check our documentation or contact support.
        </p>
        <div className="flex flex-wrap gap-3">
          <a
            href="#"
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            <ExternalLink className="w-4 h-4" />
            View Full Documentation
          </a>
          <a
            href="#"
            className="flex items-center gap-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
          >
            Report an Issue
          </a>
        </div>
      </div>
    </div>
  );
}

function QuickLink({ icon: Icon, label, href }: { icon: React.ElementType; label: string; href: string }) {
  return (
    <a
      href={href}
      className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 hover:border-blue-500/50 hover:bg-slate-800 transition-all group"
    >
      <Icon className="w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform" />
      <span className="font-medium text-white">{label}</span>
    </a>
  );
}
