'use client';

import { useApp } from '@/lib/store';
import Sidebar from '@/components/Sidebar';
import TopBar from '@/components/TopBar';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { state } = useApp();

  if (state.isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-slate-400">Loading SecureWatch...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <Sidebar />
      <div className={cn(
        'transition-all duration-200',
        state.sidebarCollapsed ? 'lg:pl-20' : 'lg:pl-72'
      )}>
        <TopBar />
        <main className="p-4 lg:p-6 pt-20 lg:pt-6">
          {children}
        </main>
      </div>
    </div>
  );
}
