'use client';

import { useState } from 'react';
import { Bell, Search, X } from 'lucide-react';
import { useApp } from '@/lib/store';
import { formatRelativeTime, getEventTypeColor, getEventTypeLabel } from '@/lib/utils';

export default function TopBar() {
  const { state } = useApp();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const unreadEvents = state.events.filter(e => !e.isRead).slice(0, 5);

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 lg:px-6">
      {/* Mobile logo */}
      <div className="flex items-center gap-3 lg:hidden">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
          <span className="text-white font-bold text-sm">SW</span>
        </div>
        <span className="font-bold text-white">SecureWatch</span>
      </div>

      {/* Search */}
      <div className="hidden lg:flex flex-1 max-w-md">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
          <input
            type="text"
            placeholder="Search cameras, events, persons..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        {/* Mobile search toggle */}
        <button
          onClick={() => setShowSearch(!showSearch)}
          className="lg:hidden p-2 rounded-lg text-slate-400 hover:bg-slate-800"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <Bell className="w-5 h-5" />
            {state.dashboardStats.unreadEvents > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold text-white">
                {state.dashboardStats.unreadEvents > 9 ? '9+' : state.dashboardStats.unreadEvents}
              </span>
            )}
          </button>

          {/* Notifications dropdown */}
          {showNotifications && (
            <>
              <div 
                className="fixed inset-0 z-40" 
                onClick={() => setShowNotifications(false)}
              />
              <div className="absolute right-0 top-full mt-2 w-80 bg-slate-800 rounded-xl border border-slate-700 shadow-xl z-50 overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-700">
                  <h3 className="font-semibold text-white">Notifications</h3>
                  <p className="text-xs text-slate-500">
                    {state.dashboardStats.unreadEvents} unread events
                  </p>
                </div>
                <div className="max-h-96 overflow-y-auto">
                  {unreadEvents.length === 0 ? (
                    <div className="px-4 py-8 text-center">
                      <Bell className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                      <p className="text-slate-500 text-sm">No new notifications</p>
                    </div>
                  ) : (
                    unreadEvents.map((event) => (
                      <div
                        key={event.id}
                        className="px-4 py-3 hover:bg-slate-700/50 transition-colors cursor-pointer border-b border-slate-700/50 last:border-0"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-lg bg-slate-700 flex-shrink-0 flex items-center justify-center">
                            {event.thumbnailPath ? (
                              <div className="w-full h-full rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20" />
                            ) : (
                              <Bell className="w-5 h-5 text-slate-500" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-white font-medium truncate">
                              {event.cameraName}
                            </p>
                            <p className="text-xs text-slate-400">
                              {getEventTypeLabel(event.type)} detected
                            </p>
                            <p className="text-xs text-slate-500 mt-1">
                              {formatRelativeTime(event.createdAt)}
                            </p>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${getEventTypeColor(event.type)}`}>
                            {getEventTypeLabel(event.type)}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                <div className="px-4 py-3 border-t border-slate-700">
                  <button 
                    onClick={() => setShowNotifications(false)}
                    className="w-full text-center text-sm text-blue-400 hover:text-blue-300 font-medium"
                  >
                    View all events
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Mobile search expanded */}
      {showSearch && (
        <div className="absolute inset-x-0 top-0 bg-slate-900 p-4 z-50 lg:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
              className="w-full pl-10 pr-10 py-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={() => setShowSearch(false)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
