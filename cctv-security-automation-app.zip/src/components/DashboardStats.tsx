'use client';

import { useApp } from '@/lib/store';
import { 
  Video, 
  AlertTriangle, 
  Eye, 
  HardDrive,
  Activity,
  Shield,
  UserCheck,
  Clock
} from 'lucide-react';
import Link from 'next/link';
import { formatRelativeTime, getEventTypeColor, getEventTypeLabel, cn } from '@/lib/utils';

export default function DashboardStats() {
  const { state } = useApp();
  const { dashboardStats, cameras, events } = state;

  const recentEvents = events.slice(0, 5);
  const onlineCameras = cameras.filter(c => c.status === 'online');
  const offlineCameras = cameras.filter(c => c.status === 'offline');

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Video}
          label="Total Cameras"
          value={dashboardStats.totalCameras}
          subValue={`${onlineCameras.length} online`}
          color="blue"
          href="/cameras"
        />
        <StatCard
          icon={Activity}
          label="Today's Events"
          value={dashboardStats.todayEvents}
          subValue={`${dashboardStats.unreadEvents} unread`}
          color="amber"
          href="/events"
        />
        <StatCard
          icon={HardDrive}
          label="Storage Used"
          value={`${dashboardStats.storageUsed.toFixed(1)} GB`}
          subValue={`of ${state.storageSettings.maxStorageGb} GB`}
          color="cyan"
          href="/settings/storage"
        />
        <StatCard
          icon={Shield}
          label="Security Status"
          value="Armed"
          subValue="AI detection active"
          color="green"
          isStatus
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Camera Status */}
        <div className="lg:col-span-2 bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Camera Status</h2>
            <Link 
              href="/cameras"
              className="text-sm text-blue-400 hover:text-blue-300 font-medium"
            >
              View all
            </Link>
          </div>
          
          {cameras.length === 0 ? (
            <EmptyState
              icon={Video}
              title="No cameras configured"
              description="Add your first CCTV camera to start monitoring"
              action={{ label: 'Add Camera', href: '/cameras/setup' }}
            />
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {cameras.map((camera) => (
                <CameraCard key={camera.id} camera={camera} />
              ))}
            </div>
          )}
        </div>

        {/* Recent Events */}
        <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">Recent Events</h2>
            <Link 
              href="/events"
              className="text-sm text-blue-400 hover:text-blue-300 font-medium"
            >
              View all
            </Link>
          </div>

          {recentEvents.length === 0 ? (
            <EmptyState
              icon={Clock}
              title="No events yet"
              description="Events will appear here when motion or persons are detected"
            />
          ) : (
            <div className="space-y-3">
              {recentEvents.map((event) => (
                <EventItem key={event.id} event={event} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-slate-800/50 rounded-2xl border border-slate-700/50 p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Quick Actions</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <QuickAction
            icon={Video}
            label="View Live"
            description="Watch camera feeds"
            href="/cameras"
          />
          <QuickAction
            icon={Eye}
            label="Review Events"
            description="Check recent activity"
            href="/events"
          />
          <QuickAction
            icon={UserCheck}
            label="Known Persons"
            description="Manage face recognition"
            href="/persons"
          />
          <QuickAction
            icon={Shield}
            label="Detection Settings"
            description="Configure alerts"
            href="/settings/notifications"
          />
        </div>
      </div>
    </div>
  );
}

// Stat Card Component
function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  subValue, 
  color, 
  href,
  isStatus 
}: { 
  icon: React.ElementType;
  label: string;
  value: string | number;
  subValue?: string;
  color: 'blue' | 'amber' | 'cyan' | 'green' | 'red';
  href?: string;
  isStatus?: boolean;
}) {
  const colorClasses = {
    blue: 'bg-blue-500/20 text-blue-400',
    amber: 'bg-amber-500/20 text-amber-400',
    cyan: 'bg-cyan-500/20 text-cyan-400',
    green: 'bg-green-500/20 text-green-400',
    red: 'bg-red-500/20 text-red-400',
  };

  const content = (
    <div className={cn(
      'p-4 rounded-xl border border-slate-700/50 transition-all',
      href ? 'hover:border-slate-600 hover:bg-slate-800/80' : ''
    )}>
      <div className={cn(
        'w-10 h-10 rounded-lg flex items-center justify-center mb-3',
        colorClasses[color]
      )}>
        <Icon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-sm text-slate-400">{label}</p>
      {subValue && (
        <p className="text-xs text-slate-500 mt-1">{subValue}</p>
      )}
      {isStatus && (
        <div className="flex items-center gap-1.5 mt-2">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs text-green-400">Active</span>
        </div>
      )}
    </div>
  );

  if (href) {
    return <Link href={href}>{content}</Link>;
  }

  return content;
}

// Camera Card Component
function CameraCard({ camera }: { camera: { id: string; name: string; status: 'online' | 'offline' | 'error' } }) {
  const statusColors = {
    online: 'bg-green-500',
    offline: 'bg-slate-500',
    error: 'bg-red-500',
  };

  return (
    <div className="relative group">
      <div className="aspect-video rounded-lg bg-slate-700/50 overflow-hidden relative">
        {/* Thumbnail placeholder */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center">
          <Video className="w-8 h-8 text-slate-500" />
        </div>
        
        {/* Status indicator */}
        <div className="absolute top-2 right-2">
          <span className={cn(
            'w-3 h-3 rounded-full block',
            statusColors[camera.status]
          )} />
        </div>

        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Link 
            href={`/cameras/${camera.id}`}
            className="px-3 py-1.5 bg-blue-500 rounded-lg text-white text-sm font-medium hover:bg-blue-600 transition-colors"
          >
            View
          </Link>
        </div>
      </div>
      <div className="mt-2">
        <p className="text-sm font-medium text-white truncate">{camera.name}</p>
        <p className="text-xs text-slate-500 capitalize">{camera.status}</p>
      </div>
    </div>
  );
}

// Event Item Component
function EventItem({ event }: { event: { id: string; cameraName: string; type: 'motion' | 'person' | 'unknown_face' | 'known_face'; thumbnailPath?: string; personName?: string; createdAt: string; isRead: boolean } }) {
  return (
    <Link 
      href={`/events/${event.id}`}
      className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-700/50 transition-colors"
    >
      <div className="w-12 h-12 rounded-lg bg-slate-700 flex-shrink-0 flex items-center justify-center">
        {event.thumbnailPath ? (
          <div className="w-full h-full rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20" />
        ) : (
          <Activity className="w-5 h-5 text-slate-500" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">
          {event.cameraName}
        </p>
        <p className="text-xs text-slate-400">
          {event.personName || getEventTypeLabel(event.type)}
        </p>
        <p className="text-xs text-slate-500">
          {formatRelativeTime(event.createdAt)}
        </p>
      </div>
      <span className={cn(
        'px-2 py-0.5 rounded text-xs font-medium',
        getEventTypeColor(event.type)
      )}>
        {getEventTypeLabel(event.type)}
      </span>
    </Link>
  );
}

// Quick Action Component
function QuickAction({ 
  icon: Icon, 
  label, 
  description, 
  href 
}: { 
  icon: React.ElementType;
  label: string;
  description: string;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="p-4 rounded-xl border border-slate-700/50 hover:border-blue-500/50 hover:bg-slate-800/50 transition-all group"
    >
      <Icon className="w-6 h-6 text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
      <p className="font-medium text-white">{label}</p>
      <p className="text-sm text-slate-500">{description}</p>
    </Link>
  );
}

// Empty State Component
function EmptyState({ 
  icon: Icon, 
  title, 
  description, 
  action 
}: { 
  icon: React.ElementType;
  title: string;
  description: string;
  action?: { label: string; href: string };
}) {
  return (
    <div className="text-center py-8">
      <Icon className="w-12 h-12 text-slate-600 mx-auto mb-3" />
      <p className="text-slate-400 font-medium">{title}</p>
      <p className="text-sm text-slate-500 mt-1">{description}</p>
      {action && (
        <Link
          href={action.href}
          className="inline-block mt-4 px-4 py-2 bg-blue-500 rounded-lg text-white text-sm font-medium hover:bg-blue-600 transition-colors"
        >
          {action.label}
        </Link>
      )}
    </div>
  );
}
