'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  Video, 
  History, 
  Users, 
  Settings, 
  Bell, 
  HardDrive,
  ChevronLeft,
  ChevronRight,
  Shield,
  LogOut,
  Menu,
  X,
  Book
} from 'lucide-react';
import { useApp } from '@/lib/store';
import { cn } from '@/lib/utils';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Live Cameras', href: '/cameras', icon: Video },
  { name: 'Event History', href: '/events', icon: History },
  { name: 'Known Persons', href: '/persons', icon: Users },
  { name: 'Help & Docs', href: '/help', icon: Book },
];

const settingsNav = [
  { name: 'Notifications', href: '/settings/notifications', icon: Bell },
  { name: 'Storage', href: '/settings/storage', icon: HardDrive },
  { name: 'System', href: '/settings/system', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { state, dispatch, logout } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleToggle = () => {
    dispatch({ type: 'TOGGLE_SIDEBAR' });
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setMobileOpen(true)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
      >
        <Menu className="w-6 h-6" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-full bg-slate-900 border-r border-slate-800 z-50 transition-all duration-200',
          'flex flex-col',
          state.sidebarCollapsed ? 'w-20' : 'w-72',
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Header */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            {!state.sidebarCollapsed && (
              <div>
                <h1 className="font-bold text-lg text-white">SecureWatch</h1>
                <p className="text-xs text-slate-500">Security Center</p>
              </div>
            )}
          </div>
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 overflow-y-auto">
          <div className="px-3 space-y-1">
            {navigation.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                    isActive
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  )}
                >
                  <item.icon className="w-5 h-5 flex-shrink-0" />
                  {!state.sidebarCollapsed && (
                    <span className="font-medium">{item.name}</span>
                  )}
                  {!state.sidebarCollapsed && item.name === 'Event History' && state.dashboardStats.unreadEvents > 0 && (
                    <span className="ml-auto bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                      {state.dashboardStats.unreadEvents}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>

          {/* Settings section */}
          <div className="mt-8 px-3">
            {!state.sidebarCollapsed && (
              <p className="px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Settings
              </p>
            )}
            <div className="space-y-1">
              {settingsNav.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors',
                      isActive
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    )}
                  >
                    <item.icon className="w-5 h-5 flex-shrink-0" />
                    {!state.sidebarCollapsed && (
                      <span className="font-medium">{item.name}</span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800">
          <div className={cn(
            'flex items-center',
            state.sidebarCollapsed ? 'justify-center' : 'gap-3'
          )}>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white font-semibold">
              {state.user?.name?.charAt(0) || 'U'}
            </div>
            {!state.sidebarCollapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">
                  {state.user?.name || 'User'}
                </p>
                <p className="text-xs text-slate-500 truncate">
                  {state.user?.email || 'user@example.com'}
                </p>
              </div>
            )}
            <button
              onClick={handleLogout}
              className="p-2 rounded-lg text-slate-400 hover:bg-slate-800 hover:text-red-400 transition-colors"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>

          {/* Collapse toggle - desktop only */}
          <button
            onClick={handleToggle}
            className="hidden lg:flex absolute bottom-24 -right-3 w-6 h-6 rounded-full bg-slate-700 border border-slate-600 items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            {state.sidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        </div>
      </aside>
    </>
  );
}
